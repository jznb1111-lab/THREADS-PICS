"""Темы в личном чате с ботом (Bot API 10.5): Пульт, Одобрение, Комменты, Статистика.

Бот сам включает режим тем (setMySettings: has_topics_enabled, has_topic_sidebar) и создаёт темы
(createForumTopic). Номера тем хранятся в kv как topic:<ключ>. Если Telegram что-то не принял,
бот пишет всё в общий чат, как раньше, и один раз сообщает причину.
"""
TOPICS = [("pult", "🎛 Пульт"), ("approve", "✅ Одобрение"), ("comments", "💬 Комменты"), ("stats", "📊 Статистика")]
VERSION = "tasks-v1"
# куда что идёт: ошибки и уведомления в Пульт
ROUTE = {"pult": "pult", "approve": "approve", "comments": "comments", "stats": "stats", "alert": "pult"}
_cache = {}


def setup(cfg, db):
    """Один раз: включить темы и создать их. Повторно ничего не делает."""
    from .tg import api, kv_get, kv_set
    t = cfg.get("telegram") or {}
    if not (t.get("token") and t.get("chat_id")) or cfg.get("telegram", {}).get("topics") is False:
        return
    if kv_get(db, "topics_v") == VERSION:
        load(db)
        return
    if kv_get(db, "topics_err"):  # уже пробовали и не вышло: не долбим Telegram на каждом цикле
        return
    try:
        api(t["token"], "setMySettings", has_topics_enabled="true", has_topic_sidebar="true",
            allows_users_to_create_topics="false")
        for key, name in TOPICS:
            if kv_get(db, f"topic:{key}"):
                continue
            r = api(t["token"], "createForumTopic", chat_id=t["chat_id"], name=name)
            kv_set(db, f"topic:{key}", r["message_thread_id"])
            db.commit()
        kv_set(db, "topics_v", VERSION)
        db.execute("DELETE FROM kv WHERE key IN ('pult_id','pult_hash')")  # пульт заново, уже в своей теме
        db.commit()
        load(db)
        from . import pult
        pult.refresh(cfg, db, new=True)
        send(cfg, "alert", "Темы готовы: 🎛 Пульт, ✅ Одобрение, 💬 Комменты, 📊 Статистика. Новые сообщения пойдут по ним.")
    except Exception as e:  # noqa: BLE001
        kv_set(db, "topics_err", str(e)[:300])
        db.commit()
        from .tg import notify
        notify(cfg, f"Темы в чате включить не получилось, пишу всё в общий чат. Ответ Telegram: {str(e)[:200]}")


def load(db):
    _cache.clear()
    for r in db.execute("SELECT key, value FROM kv WHERE key LIKE 'topic:%'"):
        _cache[r["key"][6:]] = int(r["value"])


def thread(kind) -> dict:
    """Параметр message_thread_id для темы этого вида сообщений (или пусто, если тем нет)."""
    if not _cache:
        try:
            from .cli import get_db, load_config
            db = get_db(load_config())
            try:
                if (db.execute("SELECT value FROM kv WHERE key='topics_v'").fetchone() or [None])[0] == VERSION:
                    load(db)
            finally:
                db.close()
        except Exception:  # noqa: BLE001
            pass
    tid = _cache.get(ROUTE.get(kind, "pult"))
    return {"message_thread_id": tid} if tid else {}


def send(cfg, kind, text, html=False, **kw):
    from .tg import api
    t = cfg["telegram"]
    return api(t["token"], "sendMessage", chat_id=t["chat_id"], text=text, disable_web_page_preview="true",
               **({"parse_mode": "HTML"} if html else {}), **thread(kind), **kw)


# ---------- Rich Messages: раскрывающиеся цитаты и таблицы ----------
def send_rich(cfg, kind, html_text, fallback_html, reply_markup=None):
    """Пробует sendRichMessage; если Telegram не принял, шлёт обычное HTML-сообщение. Возвращает (message, rich)."""
    from .tg import api
    t = cfg["telegram"]
    extra = {"reply_markup": reply_markup} if reply_markup else {}
    if not _rich_off():
        try:
            return api(t["token"], "sendRichMessage", chat_id=t["chat_id"], rich_message={"html": html_text},
                       **thread(kind), **extra), True
        except RuntimeError as e:
            _rich_failed(cfg, e)
    return api(t["token"], "sendMessage", chat_id=t["chat_id"], text=fallback_html, parse_mode="HTML",
               disable_web_page_preview="true", **thread(kind), **extra), False


def edit_rich(cfg, message_id, html_text, fallback_html, reply_markup=None):
    from .tg import api
    t = cfg["telegram"]
    extra = {"reply_markup": reply_markup} if reply_markup else {}
    if not _rich_off():
        try:
            api(t["token"], "editMessageText", chat_id=t["chat_id"], message_id=int(message_id),
                rich_message={"html": html_text}, **extra)
            return
        except RuntimeError as e:
            if "not modified" in str(e):
                return
            _rich_failed(cfg, e)
    api(t["token"], "editMessageText", chat_id=t["chat_id"], message_id=int(message_id), text=fallback_html,
        parse_mode="HTML", disable_web_page_preview="true", **extra)


_RICH = {"off": False, "told": False}


def _rich_off():
    return _RICH["off"]


def _rich_failed(cfg, e):
    msg = str(e)
    # не та разметка или метод не поддерживается: выключаем до перезапуска и один раз сообщаем
    if any(s in msg.lower() for s in ("not found", "can't parse", "unsupported", "bad request", "method")):
        _RICH["off"] = True
        if not _RICH["told"]:
            _RICH["told"] = True
            from .tg import notify
            notify(cfg, f"Красивые таблицы (Rich Messages) Telegram не принял, показываю как раньше. Ответ: {msg[:200]}")


def table(head, rows):
    """HTML-таблица для Rich Message."""
    import html
    e = lambda v: html.escape("—" if v is None else str(v))  # noqa: E731
    h = "".join(f"<th>{e(x)}</th>" for x in head)
    b = "".join("<tr>" + "".join(f"<td>{e(x)}</td>" for x in r) + "</tr>" for r in rows)
    return f"<table><tr>{h}</tr>{b}</table>"

