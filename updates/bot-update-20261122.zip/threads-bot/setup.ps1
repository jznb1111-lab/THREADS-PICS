# Called from install_autorun.bat. Stops the old bot, adds autostart at login and a desktop shortcut.
param([string]$Dir)
$Dir = (Resolve-Path $Dir).Path.TrimEnd('\')
Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -like '*bot.cli run*' } |
  ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
$sh = New-Object -ComObject WScript.Shell
$lnk = $sh.CreateShortcut((Join-Path ([Environment]::GetFolderPath('Startup')) 'ThreadsBot.lnk'))
$lnk.TargetPath = Join-Path $env:WINDIR 'System32\wscript.exe'
$lnk.Arguments = '"' + $Dir + '\auto.vbs"'
$lnk.WorkingDirectory = $Dir
$lnk.Save()
$port = 8765
try { $cfg = Get-Content (Join-Path $Dir 'config.json') -Raw -Encoding UTF8 | ConvertFrom-Json; if ($cfg.web_port) { $port = $cfg.web_port } } catch {}
$url = Join-Path ([Environment]::GetFolderPath('Desktop')) 'Threads bot.url'
Set-Content -Path $url -Value "[InternetShortcut]`r`nURL=http://127.0.0.1:$port/" -Encoding ASCII
Write-Output $port
