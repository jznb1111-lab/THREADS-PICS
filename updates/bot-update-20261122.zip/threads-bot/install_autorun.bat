@echo off
chcp 65001 >nul
cd /d "%~dp0"
rem Один раз (и после каждого обновления бота): автозапуск без окон + ярлык на рабочем столе
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup.ps1" -Dir "%~dp0." >nul
schtasks /create /f /tn "ThreadsBot auto" /tr "wscript.exe \"%~dp0auto.vbs\"" /sc minute /mo 15 >nul
schtasks /create /f /tn "ThreadsBot tokens" /tr "wscript.exe \"%~dp0refresh.vbs\"" /sc monthly /d 1 /st 05:00 >nul
wscript.exe "%~dp0auto.vbs"
echo.
echo Готово. Бот работает в фоне, без окон: стартует при входе в Windows и проверяется каждые 15 минут.
echo Управление с компьютера: ярлык "Threads bot" на рабочем столе (откроется через 5 секунд).
timeout /t 5 /nobreak >nul
start "" http://127.0.0.1:8765/
pause
