import sqlite3
from pathlib import Path

SCHEMA = """
CREATE TABLE IF NOT EXISTS ideas (
    id INTEGER PRIMARY KEY,
    source TEXT,            -- 'manual', 'search', ...
    url TEXT UNIQUE,
    author TEXT,
    text TEXT NOT NULL,
    likes INTEGER DEFAULT 0,
    replies INTEGER DEFAULT 0,
    used_by TEXT,           -- аккаунт, которому отдали идею (одна идея = один аккаунт)
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS drafts (
    id INTEGER PRIMARY KEY,
    account TEXT NOT NULL,  -- 'A', 'B', 'C'
    idea_id INTEGER,
    text TEXT NOT NULL,
    visual_kind TEXT,       -- 'chart', 'card', 'none'
    visual_spec TEXT,       -- JSON: что рисовать
    image_path TEXT,
    status TEXT DEFAULT 'new',   -- new -> approved -> scheduled -> published | rejected | failed
    scheduled_at TEXT,
    error TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS posts (
    id INTEGER PRIMARY KEY,
    draft_id INTEGER,
    account TEXT,
    media_id TEXT,
    permalink TEXT,
    published_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS metrics (
    post_id INTEGER,
    taken_at TEXT DEFAULT CURRENT_TIMESTAMP,
    views INTEGER, likes INTEGER, replies INTEGER, reposts INTEGER, quotes INTEGER, shares INTEGER
);
CREATE TABLE IF NOT EXISTS comments (
    id TEXT PRIMARY KEY,        -- id ответа в Threads
    post_id INTEGER,            -- наш пост (posts.id)
    account TEXT,
    username TEXT,
    text TEXT,
    ts TEXT,
    status TEXT DEFAULT 'new',  -- new -> drafted -> approved -> answered | skipped | failed
    reply_text TEXT,
    reply_media_id TEXT,
    error TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS reported (post_id INTEGER, kind TEXT, PRIMARY KEY (post_id, kind));
CREATE TABLE IF NOT EXISTS tg_sent (draft_id INTEGER PRIMARY KEY, message_id INTEGER);
CREATE TABLE IF NOT EXISTS kv (key TEXT PRIMARY KEY, value TEXT);
"""


def connect(path: str | Path) -> sqlite3.Connection:
    # timeout + WAL: бот и веб-интерфейс работают с базой одновременно
    conn = sqlite3.connect(path, timeout=30, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.executescript(SCHEMA)
    return conn
