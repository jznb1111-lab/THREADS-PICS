"""Веб-интерфейс бота на этом компьютере: http://127.0.0.1:8765

Работает внутри процесса `bot.cli run` (ярлык «Threads bot» на рабочем столе). Слушает только localhost.
Те же действия, что кнопки в Telegram: одобрить/отклонить/править посты, очередь (сдвинуть, сейчас, снять,
вернуть), комменты и ответы, статистика и переходы в воронку.
"""
import json
from datetime import datetime, timedelta, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

HTML = (Path(__file__).resolve().parent / "web.html")
ALLOWED_HOSTS = {"127.0.0.1", "localhost"}


def _ctx():
    from .cli import get_db, load_config
    cfg = load_config()
    return cfg, get_db(cfg)


def _spec(s):
    try:
        return json.loads(s or "{}")
    except ValueError:
        return {}


def _draft_json(d):
    s = _spec(d["visual_spec"])
    return {"id": d["id"], "account": d["account"], "text": d["text"], "status": d["status"],
            "scheduled_at": d["scheduled_at"], "visual": d["visual_kind"], "role": s.get("role"), "hook": s.get("hook"),
            "has_image": bool(d["image_path"] and Path(d["image_path"]).exists()), "error": d["error"]}


def state():
    from . import reports
    cfg, db = _ctx()
    try:
        accs = {k: {"username": (v.get("username") or k).lstrip("@"), "name": v.get("name")} for k, v in cfg["accounts"].items()}
        q = lambda sql, *a: [_draft_json(r) for r in db.execute(sql, a)]  # noqa: E731
        new = q("SELECT * FROM drafts WHERE status='new' ORDER BY id")
        queue = q("SELECT * FROM drafts WHERE status IN ('scheduled','approved') ORDER BY scheduled_at IS NULL, scheduled_at")
        held = q("SELECT * FROM drafts WHERE status IN ('held','failed') ORDER BY id DESC LIMIT 30")
        reserve = db.execute("SELECT account, COUNT(*) n FROM drafts WHERE status='reserve' GROUP BY account").fetchall()
        rows = reports.week_rows(db, 30)
        published = [{**r, "views": r["views"] or 0, "likes": r["likes"] or 0, "replies": r["replies"] or 0,
                      "reposts": (r["reposts"] or 0) + (r["quotes"] or 0)} for r in reversed(rows)]
        week = reports.week_rows(db, 7)
        summary = {k: reports.group(week, k) for k in ("account", "role", "hook")}
        comments = [dict(r) for r in db.execute(
            """SELECT c.*, d.id draft_id, d.text post_text FROM comments c LEFT JOIN posts p ON p.id=c.post_id
               LEFT JOIN drafts d ON d.id=p.draft_id WHERE c.status IN ('new','drafted','failed') ORDER BY c.ts DESC LIMIT 100""")]
        now = datetime.now(timezone.utc)
        funnel = reports.funnel_starts(cfg, now - timedelta(days=7), now)
        funnel_prev = reports.funnel_starts(cfg, now - timedelta(days=14), now - timedelta(days=7))
        daily = {}
        for r in rows:
            day = (r["published_at"] or "")[:10]
            daily.setdefault(day, {"A": 0, "B": 0, "C": 0})[r["account"]] += r["views"] or 0
        days = [(now - timedelta(days=i)).date().isoformat() for i in range(13, -1, -1)]
        return {"accounts": accs, "new": new, "queue": queue, "held": held,
                "reserve": {r["account"]: r["n"] for r in reserve}, "published": published, "summary": summary,
                "comments": comments, "funnel": funnel, "funnel_prev": funnel_prev,
                "daily": [{"day": d, **daily.get(d, {"A": 0, "B": 0, "C": 0})} for d in days],
                "paused": (Path(__file__).resolve().parent.parent / "api_blocked_until.txt").exists()}
    finally:
        db.close()


def act(body):
    from . import actions
    cfg, db = _ctx()
    a, i, text = body.get("act"), body.get("id"), body.get("text")
    from .tg import kv_set
    kv_set(db, "kick", "1")  # основной цикл бота подхватит изменения в течение минуты
    db.commit()
    try:
        if a == "approve":
            actions.approve(cfg, db, i); return "Одобрено, встанет в расписание в течение минуты"
        if a == "reject":
            actions.reject(cfg, db, i); return "Отклонено, вместо него пришлю запасной"
        if a == "edit":
            actions.edit(cfg, db, i, text)
            db.execute("DELETE FROM tg_sent WHERE draft_id=? AND (SELECT status FROM drafts WHERE id=?)='new'", (int(i), int(i)))
            db.commit()
            return "Текст сохранён"
        if a == "move":
            t = actions.move(cfg, db, i, float(body.get("hours") or 2)); return f"Сдвинул на {t:%d.%m %H:%M}"
        if a == "now":
            actions.publish_now(cfg, db, i); return "Выйдет в ближайшие минуты (не раньше часа после прошлого поста аккаунта)"
        if a == "hold":
            actions.hold(cfg, db, i); return "Снят с очереди"
        if a == "unhold":
            actions.unhold(cfg, db, i); return "Вернул в очередь"
        if a == "skip":
            actions.skip_comment(cfg, db, i); return "Пропустил"
        if a == "reply_reject":
            actions.reject_reply(cfg, db, i); return "Утром будет другой вариант"
        if a == "reply":
            actions.approve_reply(cfg, db, i, text=text); return "Ответ опубликован"
        raise actions.ActionError("неизвестное действие")
    finally:
        db.close()


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):  # тихо, без окна
        pass

    def _host_ok(self):
        host = (self.headers.get("Host") or "").split(":")[0]
        return host in ALLOWED_HOSTS

    def _send(self, code, body, ctype="application/json; charset=utf-8"):
        data = body if isinstance(body, bytes) else body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        if not self._host_ok():
            return self._send(403, "{}")
        path = urlparse(self.path).path
        try:
            if path == "/":
                return self._send(200, HTML.read_bytes(), "text/html; charset=utf-8")
            if path == "/api/state":
                return self._send(200, json.dumps(state(), ensure_ascii=False, default=str))
            if path.startswith("/img/"):
                cfg, db = _ctx()
                r = db.execute("SELECT image_path FROM drafts WHERE id=?", (int(path[5:]),)).fetchone()
                db.close()
                if r and r["image_path"] and Path(r["image_path"]).exists():
                    return self._send(200, Path(r["image_path"]).read_bytes(), "image/png")
            return self._send(404, "{}")
        except Exception as e:  # noqa: BLE001
            return self._send(500, json.dumps({"error": str(e)}, ensure_ascii=False))

    def do_POST(self):
        # свой заголовок не может прислать чужая страница из браузера: защита от подделки запросов
        if not self._host_ok() or self.headers.get("X-Bot") != "1":
            return self._send(403, "{}")
        if urlparse(self.path).path != "/api/act":
            return self._send(404, "{}")
        from .actions import ActionError
        try:
            n = int(self.headers.get("Content-Length") or 0)
            body = json.loads(self.rfile.read(n) or b"{}")
            return self._send(200, json.dumps({"ok": True, "msg": act(body)}, ensure_ascii=False))
        except ActionError as e:
            return self._send(200, json.dumps({"ok": False, "msg": str(e)}, ensure_ascii=False))
        except Exception as e:  # noqa: BLE001
            return self._send(500, json.dumps({"ok": False, "msg": str(e)[:300]}, ensure_ascii=False))


def serve(port=8765):
    ThreadingHTTPServer(("127.0.0.1", port), Handler).serve_forever()
