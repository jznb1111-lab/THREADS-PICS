"""Telegram-бот управления: одобрение постов (✅ ❌ ✏️), очередь /plan, сводка /stats, ответы на комменты.

Нужен свой бот из @BotFather. Команда настройки: python -m bot.cli tg-setup <токен бота>
"""
import json
from pathlib import Path

import requests

ACC_LABEL = {"A": "A", "B": "B", "C": "C"}

TG_SCHEMA = """
CREATE TABLE IF NOT EXISTS tg_sent (draft_id INTEGER PRIMARY KEY, message_id INTEGER);
CREATE TABLE IF NOT EXISTS kv (key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS tg_csent (comment_id TEXT, kind TEXT, PRIMARY KEY (comment_id, kind));
"""


def ensure_schema(db):
    db.executescript(TG_SCHEMA)


def kv_get(db, key, default=None):
    r = db.execute("SELECT value FROM kv WHERE key=?", (key,)).fetchone()
    return r["value"] if r else default


def kv_set(db, key, value):
    db.execute("INSERT INTO kv(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, str(value)))


def api(token, method, files=None, **params):
    for k, v in list(params.items()):
        if isinstance(v, (dict, list)):
            params[k] = json.dumps(v, ensure_ascii=False)
    r = requests.post(f"https://api.telegram.org/bot{token}/{method}", data=params, files=files,
                      timeout=int(params.get("timeout", 0)) + 60)
    data = r.json()
    if not data.get("ok"):
        raise RuntimeError(f"Telegram {method}: {data.get('description')}")
    return data["result"]


def _buttons(draft_id):
    return {"inline_keyboard": [[
        {"text": "✅ В публикацию", "callback_data": f"a:{draft_id}"},
        {"text": "❌", "callback_data": f"r:{draft_id}"},
        {"text": "✏️ Свой текст", "callback_data": f"e:{draft_id}"},
    ]]}


def _caption(cfg, d):
    acc = cfg["accounts"][d["account"]]
    who = f"@{acc.get('username')}" if acc.get("username") else d["account"]
    return f"#{d['id']} · {who}\n\n{d['text']}"


def send_draft(cfg, db, d):
    t = cfg["telegram"]
    cap = _caption(cfg, d)
    if d["image_path"] and Path(d["image_path"]).exists():
        with open(d["image_path"], "rb") as f:
            m = api(t["token"], "sendPhoto", files={"photo": f}, chat_id=t["chat_id"], caption=cap[:1024],
                    reply_markup=_buttons(d["id"]))
    else:
        m = api(t["token"], "sendMessage", chat_id=t["chat_id"], text=cap, reply_markup=_buttons(d["id"]))
    db.execute("INSERT OR REPLACE INTO tg_sent(draft_id,message_id) VALUES(?,?)", (d["id"], m["message_id"]))


def _answer(token, cq_id, text=None):
    """Ответ на нажатие кнопки. Telegram принимает его ограниченное время, просроченный просто пропускаем."""
    try:
        api(token, "answerCallbackQuery", callback_query_id=cq_id, **({"text": text} if text else {}))
    except Exception:  # noqa: BLE001
        pass


def notify(cfg, text):
    t = cfg.get("telegram") or {}
    if t.get("token") and t.get("chat_id"):
        try:
            api(t["token"], "sendMessage", chat_id=t["chat_id"], text=text, disable_web_page_preview="true")
        except Exception:  # noqa: BLE001
            pass


def send_new(cfg, db, render):
    """Отправляет на одобрение все черновики со статусом new, которые ещё не отправлены."""
    ensure_schema(db)
    sent = 0
    rows = list(db.execute("SELECT * FROM drafts WHERE status='new' AND id NOT IN (SELECT draft_id FROM tg_sent) ORDER BY id"))
    for d in rows:
        if d["visual_kind"] != "none" and not d["image_path"]:
            try:
                path = render(cfg, d)
                db.execute("UPDATE drafts SET image_path=? WHERE id=?", (path, d["id"]))
                d = dict(d, image_path=path)
            except Exception as e:  # noqa: BLE001
                notify(cfg, f"#{d['id']}: картинка не собралась ({e}), шлю без неё")
        send_draft(cfg, db, d)
        sent += 1
        db.commit()
    return sent


def replace_rejected(cfg, db, draft_id):
    """Вместо отклонённого поста сразу готовит другой для того же аккаунта:
    сначала из запаса утренней пачки, если запас кончился — пишет локальная модель (Ollama)."""
    acc = db.execute("SELECT account FROM drafts WHERE id=?", (draft_id,)).fetchone()["account"]
    r = db.execute("SELECT id FROM drafts WHERE account=? AND status='reserve' ORDER BY id LIMIT 1", (acc,)).fetchone()
    if r:
        db.execute("UPDATE drafts SET status='new' WHERE id=?", (r["id"],))
        db.commit()
        return True
    if not (cfg.get("ollama") or {}).get("enabled"):
        notify(cfg, f"Запаса для {acc} нет, замена придёт с утренней пачкой.")
        return False
    try:
        from .local_llm import make_drafts
        from .cli import _import_items
        recent = [x["text"] for x in db.execute("SELECT text FROM drafts WHERE account=? ORDER BY id DESC LIMIT 20", (acc,))]
        added, _ = _import_items(db, make_drafts(acc, n=1, recent=recent,
                                                 model=(cfg.get("ollama") or {}).get("model", "qwen3:8b")))
        return bool(added)
    except Exception as e:  # noqa: BLE001
        notify(cfg, f"Запас постов для {acc} кончился, а локальная модель не ответила ({str(e)[:120]}). Замена придёт с утренней пачкой.")
        return False


COMMANDS = [
    {"command": "plan", "description": "Очередь: что и когда выйдет"},
    {"command": "stats", "description": "Сводка за 7 дней и переходы"},
    {"command": "status", "description": "Сколько постов в каждом статусе"},
    {"command": "help", "description": "Что умеет бот"},
]
HELP = ("Что я умею:\n"
        "/plan — очередь на 2 дня с кнопками: ⏩ сдвинуть на 2 ч, 🚀 выпустить сейчас, 🗑 снять\n"
        "/stats — сводка за неделю: аккаунты, задачи постов, хуки, переходы в воронку\n"
        "/status — сколько постов в каждом статусе\n\n"
        "Сам присылаю: посты на одобрение, «пост вышел», цифры через сутки, сводку по понедельникам, "
        "новые комменты и готовые ответы на них.\n"
        "Всё то же самое с компьютера: ярлык «Threads bot» на рабочем столе.")


def ensure_commands(cfg, db):
    t = cfg["telegram"]
    if kv_get(db, "tg_commands") == "v2":
        return
    try:
        api(t["token"], "setMyCommands", commands=COMMANDS)
        kv_set(db, "tg_commands", "v2")
    except Exception:  # noqa: BLE001
        pass


# ---------- очередь ----------
def plan_view(cfg, db, hours=48):
    from datetime import datetime, timedelta
    from zoneinfo import ZoneInfo
    tz = ZoneInfo(cfg.get("timezone", "Europe/Chisinau"))
    limit = (datetime.now(tz) + timedelta(hours=hours)).isoformat()
    rows = list(db.execute("SELECT * FROM drafts WHERE status='scheduled' AND scheduled_at<=? ORDER BY scheduled_at LIMIT 15",
                           (limit,)))
    waiting = db.execute("SELECT COUNT(*) c FROM drafts WHERE status='new'").fetchone()["c"]
    later = db.execute("SELECT COUNT(*) c FROM drafts WHERE status='scheduled' AND scheduled_at>?", (limit,)).fetchone()["c"]
    if not rows:
        text = "🗓 В ближайшие 2 дня ничего не запланировано."
    else:
        lines = ["🗓 Очередь на 2 дня:"]
        for d in rows:
            when = datetime.fromisoformat(d["scheduled_at"]).astimezone(tz)
            who = (cfg["accounts"].get(d["account"]) or {}).get("username") or d["account"]
            first = d["text"].strip().split("\n")[0][:55]
            lines.append(f"#{d['id']} {when:%d.%m %H:%M} @{who.lstrip('@')}: {first}")
        text = "\n".join(lines)
    extra = []
    if later:
        extra.append(f"дальше в очереди ещё {later}")
    if waiting:
        extra.append(f"ждут одобрения {waiting}")
    if extra:
        text += "\n\n" + ", ".join(extra).capitalize()
    kb = [[{"text": f"⏩ #{d['id']}", "callback_data": f"m:{d['id']}"},
           {"text": f"🚀 #{d['id']}", "callback_data": f"n:{d['id']}"},
           {"text": f"🗑 #{d['id']}", "callback_data": f"h:{d['id']}"}] for d in rows]
    kb.append([{"text": "🔄 Обновить", "callback_data": "p:0"}])
    return text, {"inline_keyboard": kb}


def send_plan(cfg, db):
    t = cfg["telegram"]
    text, kb = plan_view(cfg, db)
    api(t["token"], "sendMessage", chat_id=t["chat_id"], text=text, reply_markup=kb)


# ---------- комменты ----------
def _comment_card(cfg, db, c, kind):
    post = db.execute("SELECT d.id, d.text FROM posts p JOIN drafts d ON d.id=p.draft_id WHERE p.id=?", (c["post_id"],)).fetchone()
    who = (cfg["accounts"].get(c["account"]) or {}).get("username") or c["account"]
    head = f"💬 Коммент под #{post['id'] if post else '?'} · @{who.lstrip('@')}"
    if post:
        head += f"\n«{post['text'].strip().split(chr(10))[0][:60]}»"
    body = f"{head}\n\n@{c['username'] or '?'}: {c['text']}"
    if kind == "draft":
        body += f"\n\nОтвет: {c['reply_text']}"
        kb = [[{"text": "✅ Ответить", "callback_data": f"ca:{c['id']}"},
               {"text": "❌", "callback_data": f"cr:{c['id']}"},
               {"text": "✏️ Свой текст", "callback_data": f"ce:{c['id']}"}]]
    else:
        body += "\n\nОтвет подготовлю утром. Можно ответить своим текстом сейчас."
        kb = [[{"text": "✏️ Ответить сам", "callback_data": f"ce:{c['id']}"},
               {"text": "🙈 Пропустить", "callback_data": f"cs:{c['id']}"}]]
    return body[:4000], {"inline_keyboard": kb}


def send_comments(cfg, db) -> int:
    """Новые комменты и готовые ответы, которые ещё не показывали."""
    ensure_schema(db)
    t = cfg["telegram"]
    n = 0
    for kind, status in (("new", "new"), ("draft", "drafted")):
        rows = list(db.execute("SELECT * FROM comments WHERE status=? AND id NOT IN "
                               "(SELECT comment_id FROM tg_csent WHERE kind=?) ORDER BY ts LIMIT 20", (status, kind)))
        for c in rows:
            text, kb = _comment_card(cfg, db, c, kind)
            api(t["token"], "sendMessage", chat_id=t["chat_id"], text=text, reply_markup=kb, disable_web_page_preview="true")
            db.execute("INSERT OR IGNORE INTO tg_csent(comment_id,kind) VALUES(?,?)", (c["id"], kind))
            db.commit()
            n += 1
    return n


def _close_buttons(t, chat, msg, label):
    try:
        api(t["token"], "editMessageReplyMarkup", chat_id=chat, message_id=msg["message_id"],
            reply_markup={"inline_keyboard": [[{"text": label, "callback_data": "noop:0"}]]})
    except Exception:  # noqa: BLE001
        pass


def _say(t, chat, text):
    api(t["token"], "sendMessage", chat_id=chat, text=text, disable_web_page_preview="true")


def poll(cfg, db, wait: int = 0):
    """Читает нажатия кнопок и сообщения. Возвращает число изменений (посты, расписание, ответы)."""
    from . import actions
    from .actions import ActionError
    ensure_schema(db)
    t = cfg["telegram"]
    chat = str(t["chat_id"])
    ensure_commands(cfg, db)
    offset = int(kv_get(db, "tg_offset", 0))
    changed = 0
    for u in api(t["token"], "getUpdates", offset=offset, timeout=wait):
        kv_set(db, "tg_offset", u["update_id"] + 1)
        db.commit()
        cq = u.get("callback_query")
        if cq and str(cq["message"]["chat"]["id"]) == chat:
            act, _, sid = cq["data"].partition(":")
            msg = cq["message"]
            try:
                if act == "noop":
                    _answer(t["token"], cq["id"])
                elif act == "e":
                    actions._draft(db, sid)
                    kv_set(db, "awaiting_edit", f"d:{sid}")
                    db.commit()
                    _answer(t["token"], cq["id"])
                    _say(t, chat, f"Пришлите новый текст для #{sid} одним сообщением.")
                elif act in ("a", "r"):
                    (actions.approve if act == "a" else actions.reject)(cfg, db, sid)
                    changed += 1
                    _answer(t["token"], cq["id"], "Одобрено, поставлю в расписание" if act == "a" else "Отклонено, присылаю замену")
                    _close_buttons(t, chat, msg, "✅ одобрено" if act == "a" else "❌ отклонено")
                elif act in ("m", "n", "h", "p"):
                    note = None
                    if act == "m":
                        when = actions.move(cfg, db, sid)
                        note = f"#{sid} → {when:%d.%m %H:%M}"
                    elif act == "n":
                        actions.publish_now(cfg, db, sid)
                        note = f"#{sid} выйдет в ближайшие минуты (не раньше часа после прошлого поста аккаунта)"
                    elif act == "h":
                        actions.hold(cfg, db, sid)
                        note = f"#{sid} снят с очереди. Вернуть можно в веб-интерфейсе"
                    changed += act != "p"
                    _answer(t["token"], cq["id"], note)
                    text, kb = plan_view(cfg, db)
                    try:
                        api(t["token"], "editMessageText", chat_id=chat, message_id=msg["message_id"], text=text, reply_markup=kb)
                    except Exception:  # noqa: BLE001
                        pass  # «message is not modified»
                elif act == "ce":
                    actions._comment(db, sid)
                    kv_set(db, "awaiting_edit", f"c:{sid}")
                    db.commit()
                    _answer(t["token"], cq["id"])
                    _say(t, chat, "Пришлите текст ответа одним сообщением, я сразу опубликую его под комментом.")
                elif act == "cs":
                    actions.skip_comment(cfg, db, sid)
                    _answer(t["token"], cq["id"], "Пропускаю")
                    _close_buttons(t, chat, msg, "🙈 пропущено")
                elif act == "cr":
                    actions.reject_reply(cfg, db, sid)
                    db.execute("DELETE FROM tg_csent WHERE comment_id=? AND kind='draft'", (sid,))
                    db.commit()
                    _answer(t["token"], cq["id"], "Утром будет другой вариант")
                    _close_buttons(t, chat, msg, "❌ другой вариант утром")
                elif act == "ca":
                    actions.approve_reply(cfg, db, sid)
                    changed += 1
                    _answer(t["token"], cq["id"], "Ответ опубликован")
                    _close_buttons(t, chat, msg, "✅ ответ опубликован")
            except ActionError as e:
                _answer(t["token"], cq["id"], str(e)[:190])
            continue
        msg = u.get("message")
        if msg and str(msg["chat"]["id"]) == chat and msg.get("text"):
            txt = msg["text"].strip()
            if txt.startswith("/"):
                cmd = txt.split()[0].split("@")[0]
                try:
                    if cmd == "/plan":
                        send_plan(cfg, db)
                    elif cmd == "/stats":
                        from .reports import weekly_summary
                        _say(t, chat, weekly_summary(cfg, db))
                    elif cmd == "/status":
                        stats = {r["status"]: r["n"] for r in db.execute("SELECT status, COUNT(*) n FROM drafts GROUP BY status")}
                        _say(t, chat, "Черновики: " + json.dumps(stats, ensure_ascii=False))
                    elif cmd in ("/help", "/start"):
                        _say(t, chat, HELP)
                except Exception as e:  # noqa: BLE001
                    _say(t, chat, f"Не получилось: {str(e)[:200]}")
                continue
            waiting = kv_get(db, "awaiting_edit")
            if not waiting:
                continue
            kind, _, wid = (waiting if ":" in str(waiting) else f"d:{waiting}").partition(":")
            try:
                if kind == "c":
                    actions.approve_reply(cfg, db, wid, text=txt)
                    _say(t, chat, "✅ Ответ опубликован")
                else:
                    actions.edit(cfg, db, wid, txt)
                    db.execute("UPDATE drafts SET status='new' WHERE id=? AND status IN ('new','failed')", (int(wid),))
                    db.execute("DELETE FROM tg_sent WHERE draft_id=?", (int(wid),))
                    db.commit()
                    _say(t, chat, f"#{wid}: текст обновлён" + ("" if db.execute("SELECT status FROM drafts WHERE id=?", (int(wid),)).fetchone()["status"] == "new" else ", место в очереди прежнее"))
                db.execute("DELETE FROM kv WHERE key='awaiting_edit'")
                changed += 1
            except ActionError as e:
                _say(t, chat, f"{e}. Пришлите другой текст.")
    db.commit()
    return changed
