' Starts auto.bat with no window (Task Scheduler / Startup)
Set fso = CreateObject("Scripting.FileSystemObject")
d = fso.GetParentFolderName(WScript.ScriptFullName)
Set sh = CreateObject("WScript.Shell")
sh.CurrentDirectory = d
sh.Run "cmd /c """ & d & "\auto.bat""", 0, False
