"""Комменты под нашими постами.

Цикл: бот раз в час забирает новые комменты (Threads API, /conversation) → шлёт их в Telegram →
выкладывает список ждущих ответа в GitHub (state/comments_pending.json) → Claude утром пишет
ответы в пачку (элементы с "type": "reply") → бот присылает ответ на одобрение → ✅ публикует.
"""
import base64
import json
from datetime import datetime, timedelta

import requests

PENDING_PATH = "state/comments_pending.json"


def ensure_columns(db):
    have = {r[1] for r in db.execute("PRAGMA table_info(comments)")}
    for col, typ in (("depth", "INTEGER"), ("parent_id", "TEXT"), ("parent_ours", "INTEGER"), ("parent_text", "TEXT"),
                     ("ai_tries", "INTEGER DEFAULT 0")):
        if col not in have:
            db.execute(f"ALTER TABLE comments ADD COLUMN {col} {typ}")
    db.commit()


def fetch_new(cfg, db, days=7) -> list[dict]:
    """Новые чужие комменты под постами за N дней. Возвращает добавленные."""
    from .cli import client_for
    ensure_columns(db)
    added = []
    posts = list(db.execute("SELECT p.*, d.text post_text FROM posts p LEFT JOIN drafts d ON d.id=p.draft_id "
                            "WHERE p.published_at >= datetime('now', ?)", (f"-{days} days",)))
    clients = {}
    for p in posts:
        acc = p["account"]
        if acc not in clients:
            clients[acc] = client_for(cfg, acc)
        try:
            items = clients[acc].conversation(p["media_id"])
        except Exception as e:  # noqa: BLE001
            if "5258005" in str(e):
                raise
            print(f"комменты поста {p['id']}: {str(e)[:150]}")
            continue
        own_username = ((cfg["accounts"].get(acc) or {}).get("username") or "").lstrip("@").lower()
        answered_ids = {((it.get("replied_to") or {}).get("id")) for it in items
                        if it.get("is_reply_owned_by_me") or (it.get("username") or "").lower() == own_username}
        by_id = {it["id"]: it for it in items}
        ours = {it["id"] for it in items if it.get("is_reply_owned_by_me") or (it.get("username") or "").lower() == own_username}

        def depth(it, n=0):  # 0 = коммент прямо под постом, 1 = ответ на коммент и т.д.
            par = (it.get("replied_to") or {}).get("id")
            if not par or par == p["media_id"] or par not in by_id or n > 20:
                return n
            return depth(by_id[par], n + 1)
        for it in items:
            if it.get("is_reply_owned_by_me") or (it.get("username") or "").lower() == own_username:
                continue
            par = (it.get("replied_to") or {}).get("id")
            meta = (depth(it), par if par in by_id else None, int(par in ours), (by_id.get(par) or {}).get("text"))
            if not (it.get("text") or "").strip():
                continue
            status = "answered" if it["id"] in answered_ids else "new"
            cur = db.execute("INSERT OR IGNORE INTO comments(id,post_id,account,username,text,ts,status) VALUES(?,?,?,?,?,?,?)",
                             (it["id"], p["id"], acc, it.get("username"), it.get("text"), it.get("timestamp"), status))
            db.execute("UPDATE comments SET depth=?, parent_id=?, parent_ours=?, parent_text=? WHERE id=?", (*meta, it["id"]))
            if cur.rowcount and status == "new":
                added.append({"id": it["id"], "post_id": p["id"], "account": acc, "username": it.get("username"),
                              "text": it.get("text"), "post_text": p["post_text"]})
            elif it["id"] in answered_ids:
                # Илья ответил сам прямо в Threads: больше не предлагаем
                db.execute("UPDATE comments SET status='answered' WHERE id=? AND status IN ('new','drafted')", (it["id"],))
    db.commit()
    return added


def pending(db) -> list[dict]:
    q = """SELECT c.id comment_id, c.account, c.text comment, c.ts, d.text post_text, c.status
           FROM comments c LEFT JOIN posts p ON p.id=c.post_id LEFT JOIN drafts d ON d.id=p.draft_id
           WHERE c.status='new' ORDER BY c.ts"""
    return [dict(r) for r in db.execute(q)]


def push_pending(cfg, db) -> bool:
    """Кладёт в репозиторий пачек список комментов без ответа, чтобы утренний Claude написал ответы.
    Ники авторов не выкладываем: Claude нужен только текст."""
    from .tg import kv_get, kv_set
    src = cfg.get("drafts_repo") or {}
    token = src.get("token") or (cfg.get("github") or {}).get("token")
    if not (src.get("repo") and token):
        return False
    items = [{k: v for k, v in it.items() if k != "status"} for it in pending(db)]
    body = json.dumps(items, ensure_ascii=False, indent=1)
    if kv_get(db, "pending_pushed") == body:
        return False
    url = f"https://api.github.com/repos/{src['repo']}/contents/{PENDING_PATH}"
    h = {"Authorization": f"Bearer {token}", "Accept": "application/vnd.github+json"}
    branch = src.get("branch", "main")
    old = requests.get(url, headers=h, params={"ref": branch}, timeout=30)
    payload = {"message": f"comments pending: {len(items)}", "branch": branch,
               "content": base64.b64encode(body.encode("utf-8")).decode()}
    if old.status_code == 200:
        payload["sha"] = old.json()["sha"]
    r = requests.put(url, headers=h, json=payload, timeout=60)
    if r.status_code >= 300:
        raise RuntimeError(f"GitHub: {r.status_code} {r.text[:150]}")
    kv_set(db, "pending_pushed", body)
    db.commit()
    return True


def import_replies(db, items) -> int:
    """Элементы пачки {"type":"reply","comment_id":"...","text":"..."} → черновики ответов."""
    from .style import check_text
    n = 0
    for it in items:
        cid, text = str(it.get("comment_id") or ""), (it.get("text") or "").strip()
        row = db.execute("SELECT status FROM comments WHERE id=?", (cid,)).fetchone()
        if not row or row["status"] != "new" or not text or check_text(text):
            continue
        db.execute("UPDATE comments SET reply_text=?, status='drafted' WHERE id=?", (text, cid))
        n += 1
    db.commit()
    return n


def due_for_fetch(db, minutes=60) -> bool:
    from .tg import kv_get
    last = kv_get(db, "comments_fetched_at")
    return not last or datetime.fromisoformat(last) <= datetime.utcnow() - timedelta(minutes=minutes)


def mark_fetched(db):
    from .tg import kv_set
    kv_set(db, "comments_fetched_at", datetime.utcnow().isoformat())
    db.commit()
