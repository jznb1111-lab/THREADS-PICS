"""Командная строка бота. Запуск: python -m bot.cli <команда> ...

Поток: идеи -> generate (черновики) -> review/approve (человек) -> schedule -> publish-due (по cron) -> metrics -> report
"""
import argparse
import csv
import json
import random
import sys
from datetime import datetime, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

ROOT = Path(__file__).resolve().parent.parent
CONFIG_PATH = ROOT / "config.json"


def load_config() -> dict:
    if not CONFIG_PATH.exists():
        sys.exit("Нет config.json. Скопируйте config.example.json в config.json и заполните.")
    return json.loads(CONFIG_PATH.read_text(encoding="utf-8"))


def save_config(cfg: dict):
    CONFIG_PATH.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")


def get_db(cfg):
    from .db import connect
    return connect(ROOT / cfg.get("db", "bot.sqlite3"))


def client_for(cfg, account):
    from .threads_api import ThreadsClient
    a = cfg["accounts"][account]
    return ThreadsClient(a["user_id"], a["access_token"])


# ---------- идеи ----------
def cmd_add_idea(cfg, args):
    db = get_db(cfg)
    db.execute("INSERT OR IGNORE INTO ideas(source,url,author,text,likes,replies) VALUES('manual',?,?,?,?,?)",
               (args.url, args.author, args.text, args.likes, args.replies))
    db.commit()
    print("ok")


def cmd_import_ideas(cfg, args):
    """CSV с колонками: url,author,likes,replies,text"""
    db = get_db(cfg)
    n = 0
    with open(args.file, encoding="utf-8") as f:
        for row in csv.DictReader(f):
            cur = db.execute("INSERT OR IGNORE INTO ideas(source,url,author,text,likes,replies) VALUES('import',?,?,?,?,?)",
                             (row.get("url"), row.get("author"), row["text"], int(row.get("likes") or 0), int(row.get("replies") or 0)))
            n += cur.rowcount
    db.commit()
    print(f"добавлено идей: {n}")


def cmd_search(cfg, args):
    """Поиск через API. Работает по чужим постам только после одобрения threads_keyword_search."""
    db = get_db(cfg)
    c = client_for(cfg, args.account)
    n = 0
    for q in args.queries:
        for p in c.keyword_search(q, search_type=args.type):
            if not p.get("text"):
                continue
            cur = db.execute("INSERT OR IGNORE INTO ideas(source,url,author,text) VALUES('search',?,?,?)",
                             (p.get("permalink"), p.get("username"), p["text"]))
            n += cur.rowcount
    db.commit()
    print(f"новых идей: {n} (API не отдаёт лайки чужих постов, поэтому likes=0)")


# ---------- черновики ----------
def _market_note(tickers):
    from . import market
    lines = []
    for t in tickers:
        try:
            rows = market.candles(t, "1h", 24)
            period = "24 часа"
            lines.append(f"{market.NAMES_RU[t]} ({t}): последняя цена {rows[-1][4]:.{2 if rows[-1][4] > 20 else 5}f}, изменение за {period} {market.change_pct(rows):+.2f}%")
        except Exception as e:  # noqa: BLE001
            lines.append(f"{t}: нет данных ({e})")
    return "\n".join(lines)


def cmd_generate(cfg, args):
    """Платный путь через Claude API (нужен ANTHROPIC_API_KEY и pip install anthropic). Необязателен."""
    import anthropic
    from .generate import make_drafts
    db = get_db(cfg)
    ideas = [dict(r) for r in db.execute(
        "SELECT * FROM ideas WHERE used_by IS NULL ORDER BY (likes + 2*replies) DESC LIMIT ?", (args.ideas,))]
    recent = [r["text"] for r in db.execute("SELECT text FROM drafts WHERE status!='rejected' ORDER BY id DESC LIMIT 30")]
    note = _market_note(args.market.split(",")) if args.market else ""
    drafts = make_drafts(anthropic.Anthropic(), args.account, ideas, note, recent, args.n)
    for i in ideas:
        db.execute("UPDATE ideas SET used_by=? WHERE id=?", (args.account, i["id"]))
    for d in drafts:
        status = "rejected" if d["problems"] else "new"
        db.execute("INSERT INTO drafts(account,text,visual_kind,visual_spec,status,error) VALUES(?,?,?,?,?,?)",
                   (args.account, d["text"], d["visual_kind"], d["visual_spec"], status,
                    "; ".join(d["problems"]) or None))
    db.commit()
    print(f"черновиков: {len(drafts)}, из них отсеяно стоп-списком: {sum(1 for d in drafts if d['problems'])}")


TICKERS = {"XAUUSD", "XAGUSD", "EURUSD", "GBPUSD", "USDJPY", "BRENT", "SPX", "NDX"}


def cmd_import_drafts(cfg, args):
    """Бесплатный путь: черновики пишутся в проекте Claude и загружаются JSON-файлом.

    Формат: [{"account": "A", "text": "...", "topic": "Трейдинг",
              "visual": {"kind": "chart|card|none", "ticker": "XAUUSD", "card_text": "..."},
              "idea_url": "необязательно"}]
    """
    db = get_db(cfg)
    items = json.loads(Path(args.file).read_text(encoding="utf-8"))
    added, bad = _import_items(db, items)
    from .comments import import_replies
    replies = import_replies(db, [it for it in items if it.get("type") == "reply"])
    print(f"загружено: {added}, отсеяно стоп-листом: {bad}, ответов на комменты: {replies}. Дальше: python -m bot.cli review --render")


def _import_items(db, items) -> tuple[int, int]:
    from .style import check_text
    seen = {r["text"] for r in db.execute("SELECT text FROM drafts")}
    added = bad = 0
    for it in items:
        if it.get("type") == "reply":
            continue  # ответы на комменты импортирует _import_batch
        acc, text = it.get("account"), (it.get("text") or "").strip()
        if acc not in ("A", "B", "C") or text in seen:
            continue
        v = it.get("visual") or {"kind": "none"}
        kind = v.get("kind", "none")
        problems = check_text(text) + (check_text(v["card_text"]) if v.get("card_text") else [])
        if kind == "chart" and v.get("ticker") not in TICKERS:
            problems.append(f"неизвестный тикер {v.get('ticker')}")
        if kind == "card" and not v.get("card_text"):
            problems.append("для card нужен card_text")
        spec = json.dumps({**v, "topic": it.get("topic"), "role": it.get("role"), "hook": it.get("hook")}, ensure_ascii=False)
        status = "rejected" if problems else ("reserve" if it.get("reserve") else "new")
        db.execute("INSERT INTO drafts(account,text,visual_kind,visual_spec,status,error) VALUES(?,?,?,?,?,?)",
                   (acc, text, kind, spec, status, "; ".join(problems) or None))
        if it.get("idea_url"):
            db.execute("UPDATE ideas SET used_by=? WHERE url=?", (acc, it["idea_url"]))
        added += 1
        bad += bool(problems)
    db.commit()
    return added, bad


def _import_batch(db, items) -> int:
    """Пачка от Claude: посты + ответы на комменты ({"type": "reply", "comment_id": ..., "text": ...})."""
    from .comments import import_replies
    added, _ = _import_items(db, items)
    return added + import_replies(db, [it for it in items if it.get("type") == "reply"])


def _backfill_role_hook(db):
    """Разово: проставить role/hook старым черновикам из уже забранных пачек (для сводки по хукам)."""
    from .tg import kv_get, kv_set
    if kv_get(db, "backfill_rolehook"):
        return
    known = {}
    for f in list((ROOT / "drafts").glob("*.json")) + list((ROOT / "drafts" / "imported").glob("*.json")):
        try:
            for it in json.loads(f.read_text(encoding="utf-8")):
                if it.get("text") and (it.get("role") or it.get("hook")):
                    known[it["text"].strip()] = (it.get("role"), it.get("hook"))
        except Exception:  # noqa: BLE001
            continue
    for d in list(db.execute("SELECT id, text, visual_spec FROM drafts")):
        spec = json.loads(d["visual_spec"] or "{}")
        if not spec.get("role") and d["text"].strip() in known:
            spec["role"], spec["hook"] = known[d["text"].strip()]
            db.execute("UPDATE drafts SET visual_spec=? WHERE id=?", (json.dumps(spec, ensure_ascii=False), d["id"]))
    kv_set(db, "backfill_rolehook", "1")
    db.commit()


def cmd_export_context(cfg, args):
    """Собирает в context.md всё, что нужно для следующей пачки черновиков: идеи, недавние посты,
    лучшие посты по статистике и свежие цифры рынка. Этот файл загружается в проект Claude."""
    db = get_db(cfg)
    out = ["# Контекст для новых черновиков", f"Дата: {datetime.now(ZoneInfo(cfg.get('timezone', 'Europe/Chisinau'))):%d.%m.%Y %H:%M}", ""]
    if args.market:
        out += ["## Рынок", _market_note(args.market.split(",")), ""]
    out.append("## Неиспользованные идеи конкурентов")
    for r in db.execute("SELECT * FROM ideas WHERE used_by IS NULL ORDER BY (likes + 2*replies) DESC LIMIT 30"):
        out.append(f"- [{r['likes']} лайков, {r['replies']} ответов] {r['url'] or ''}\n  {r['text']}")
    out += ["", "## Наши недавние посты (не повторять)"]
    for r in db.execute("SELECT account,text FROM drafts WHERE status!='rejected' ORDER BY id DESC LIMIT 40"):
        out.append(f"- [{r['account']}] {r['text']}")
    out += ["", "## Лучшие опубликованные посты за 14 дней"]
    try:
        q = """SELECT p.account, d.text, MAX(m.views) v, MAX(m.likes) l, MAX(m.replies) rp
               FROM posts p JOIN drafts d ON d.id=p.draft_id JOIN metrics m ON m.post_id=p.id
               WHERE p.published_at >= datetime('now','-14 days') GROUP BY p.id ORDER BY v DESC LIMIT 15"""
        for r in db.execute(q):
            out.append(f"- [{r['account']}] {r['v']} просм., {r['l']} лайков, {r['rp']} ответов: {r['text']}")
    except Exception as e:  # noqa: BLE001
        out.append(f"(нет данных: {e})")
    Path(args.out).write_text("\n".join(out), encoding="utf-8")
    print(f"готово: {args.out}. Загрузите его в проект и попросите новую пачку черновиков.")


def cmd_set_token(cfg, args):
    """Сохранить токен из «Генератора токенов» Meta: python -m bot.cli set-token A <токен>"""
    import requests
    me = requests.get("https://graph.threads.net/v1.0/me",
                      params={"fields": "id,username", "access_token": args.token}, timeout=30).json()
    if "id" not in me:
        raise SystemExit(f"Токен не подошёл: {me}")
    cfg["accounts"][args.account].update(user_id=me["id"], username=me.get("username"), access_token=args.token)
    save_config(cfg)
    print(f"Готово: {args.account} = @{me.get('username')} (id {me['id']})")


def cmd_set_github(cfg, args):
    """Сохраняет репозиторий GitHub для картинок и проверяет, что токен может в него писать."""
    import requests
    repo = args.repo.strip().removeprefix("https://github.com/").strip("/")
    r = requests.get(f"https://api.github.com/repos/{repo}",
                     headers={"Authorization": f"Bearer {args.token}", "Accept": "application/vnd.github+json"}, timeout=30)
    if r.status_code != 200:
        sys.exit(f"GitHub не пустил в {repo}: {r.status_code} {r.text[:200]}")
    info = r.json()
    if info.get("private"):
        sys.exit("Репозиторий приватный: Threads не сможет забрать картинки. Сделайте его публичным.")
    if not info.get("permissions", {}).get("push"):
        sys.exit("Токен не может записывать в репозиторий: дайте ему Contents: Read and write.")
    cfg["github"] = {"repo": repo, "branch": info.get("default_branch", "main"), "token": args.token}
    save_config(cfg)
    print(f"Готово: картинки пойдут в {repo} (ветка {cfg['github']['branch']})")


def _render(cfg, draft) -> str | None:
    from . import visuals
    spec = json.loads(draft["visual_spec"] or "{}")
    out = ROOT / cfg.get("media_dir", "media") / f"draft_{draft['id']}.png"
    user = ((cfg.get("accounts") or {}).get(draft["account"]) or {}).get("username") or ""
    handle = f"@{user.lstrip('@')}" if user else ""  # подпись = ник Threads-аккаунта, который публикует пост
    if draft["visual_kind"] == "chart" and spec.get("ticker"):
        visuals.chart(draft["account"], spec["ticker"], out, handle=handle)
    elif draft["visual_kind"] == "card" and spec.get("card_text"):
        visuals.card(draft["account"], spec["card_text"], out, handle=handle)
    else:
        return None
    return str(out)


def cmd_review(cfg, args):
    db = get_db(cfg)
    q = "SELECT * FROM drafts WHERE status='new'" + (" AND account=?" if args.account else "") + " ORDER BY id"
    rows = list(db.execute(q, (args.account,) if args.account else ()))
    for d in rows:
        if args.render and d["visual_kind"] != "none" and not d["image_path"]:
            try:
                path = _render(cfg, d)
                db.execute("UPDATE drafts SET image_path=? WHERE id=?", (path, d["id"]))
                d = dict(d, image_path=path)
            except Exception as e:  # noqa: BLE001
                print(f"  ! картинка для #{d['id']} не собралась: {e}")
        print(f"\n#{d['id']} [{d['account']}] визуал: {d['visual_kind']} {d['visual_spec'] or ''}")
        if d["image_path"]:
            print(f"  картинка: {d['image_path']}")
        print("  " + d["text"].replace("\n", "\n  "))
    db.commit()
    print(f"\nвсего на проверке: {len(rows)}. Одобрить: approve ID..., отклонить: reject ID..., поправить: edit ID \"текст\"")


def cmd_approve(cfg, args):
    db = get_db(cfg)
    for i in args.ids:
        db.execute("UPDATE drafts SET status='approved' WHERE id=? AND status='new'", (i,))
    db.commit()
    print("ok")


def cmd_reject(cfg, args):
    db = get_db(cfg)
    for i in args.ids:
        db.execute("UPDATE drafts SET status='rejected' WHERE id=?", (i,))
    db.commit()
    print("ok")


def cmd_edit(cfg, args):
    from .style import check_text
    problems = check_text(args.text)
    if problems:
        sys.exit(f"текст не прошёл стоп-список: {problems}")
    db = get_db(cfg)
    db.execute("UPDATE drafts SET text=? WHERE id=?", (args.text, args.id))
    db.commit()
    print("ok")


# ---------- расписание и публикация ----------
def cmd_schedule(cfg, args):
    """Раскладывает одобренные черновики по слотам: N в день на аккаунт, случайное время в окне, не чаще чем раз в 2 часа."""
    tz = ZoneInfo(cfg.get("timezone", "Europe/Chisinau"))
    start_h, end_h = cfg.get("posting_window", [9, 23])
    db = get_db(cfg)
    for acc, acfg in cfg["accounts"].items():
        if acfg.get("paused"):
            continue  # аккаунт на паузе: одобренные ждут
        per_day = acfg.get("posts_per_day", 3)
        approved = list(db.execute("SELECT id FROM drafts WHERE account=? AND status='approved' ORDER BY id", (acc,)))
        last = db.execute("SELECT MAX(scheduled_at) m FROM drafts WHERE account=? AND status IN ('scheduled','published')", (acc,)).fetchone()["m"]
        cursor = max(datetime.now(tz), datetime.fromisoformat(last) + timedelta(hours=2) if last else datetime.now(tz))
        day_count: dict = {}
        for d in approved:
            while True:
                if cursor.hour < start_h:
                    cursor = cursor.replace(hour=start_h, minute=0)
                if cursor.hour >= end_h or day_count.get(cursor.date(), 0) >= per_day:
                    cursor = (cursor + timedelta(days=1)).replace(hour=start_h, minute=0)
                    continue
                break
            slot = cursor + timedelta(minutes=random.randint(0, 50))
            db.execute("UPDATE drafts SET status='scheduled', scheduled_at=? WHERE id=?", (slot.isoformat(), d["id"]))
            day_count[slot.date()] = day_count.get(slot.date(), 0) + 1
            cursor = slot + timedelta(hours=random.uniform(2, 4))
            print(f"#{d['id']} [{acc}] -> {slot:%d.%m %H:%M}")
    db.commit()


def _github_upload(gh: dict, path: str) -> str:
    """Заливает картинку в публичный репозиторий GitHub и возвращает прямую ссылку raw.githubusercontent.com."""
    import base64
    import requests
    repo, branch = gh["repo"], gh.get("branch", "main")
    name = f"media/{Path(path).name}"
    api = f"https://api.github.com/repos/{repo}/contents/{name}"
    h = {"Authorization": f"Bearer {gh['token']}", "Accept": "application/vnd.github+json"}
    body = {"message": f"add {Path(path).name}", "branch": branch,
            "content": base64.b64encode(Path(path).read_bytes()).decode()}
    old = requests.get(api, headers=h, params={"ref": branch}, timeout=30)
    if old.status_code == 200:
        body["sha"] = old.json()["sha"]
    r = requests.put(api, headers=h, json=body, timeout=60)
    if r.status_code >= 300:
        raise RuntimeError(f"GitHub не принял картинку: {r.status_code} {r.text[:200]}")
    return f"https://raw.githubusercontent.com/{repo}/{branch}/{name}"


def _public_url(cfg, path: str) -> str:
    gh = cfg.get("github") or {}
    if gh.get("repo") and gh.get("token"):
        return _github_upload(gh, path)
    base = cfg.get("media_base_url")
    if not base:
        raise RuntimeError("для картинок нужен github (repo + token) или media_base_url (см. README)")
    return base.rstrip("/") + "/" + Path(path).name


def cmd_publish_due(cfg, args):
    tz = ZoneInfo(cfg.get("timezone", "Europe/Chisinau"))
    db = get_db(cfg)
    now = datetime.now(tz).isoformat()
    gap = int(cfg.get("min_gap_minutes", 60))
    block_flag = Path(__file__).resolve().parent.parent / "api_blocked_until.txt"
    if block_flag.exists():
        try:
            until = datetime.fromisoformat(block_flag.read_text().strip())
            if datetime.now(tz) < until:
                print(f"API на паузе до {until:%d.%m %H:%M} (блок Meta). Удали api_blocked_until.txt, чтобы попробовать раньше.")
                return
        except ValueError:
            pass
        block_flag.unlink(missing_ok=True)
    done_accs = set()
    for d in list(db.execute("SELECT * FROM drafts WHERE status='scheduled' AND scheduled_at<=? ORDER BY scheduled_at", (now,))):
        acc = d["account"]
        if cfg["accounts"].get(acc, {}).get("paused"):
            continue
        # не больше одного поста на аккаунт за запуск и не чаще раза в gap минут:
        # после простоя ПК просроченные посты выходят по одному, а не пачкой
        if acc in done_accs:
            continue
        recent = db.execute("SELECT 1 FROM posts WHERE account=? AND published_at >= datetime('now', ?)",
                            (acc, f"-{gap} minutes")).fetchone()
        if recent:
            continue
        done_accs.add(acc)
        topic = json.loads(d["visual_spec"] or "{}").get("topic")
        try:
            c = client_for(cfg, acc)
            img = d["image_path"] or (_render(cfg, d) if d["visual_kind"] != "none" else None)
            if args.dry_run:
                print(f"[dry-run] #{d['id']} [{acc}] {'с картинкой ' + img if img else 'текст'}: {d['text'][:60]}")
                continue
            res = c.post_image(d["text"], _public_url(cfg, img), topic) if img else c.post_text(d["text"], topic)
            db.execute("INSERT INTO posts(draft_id,account,media_id,permalink) VALUES(?,?,?,?)",
                       (d["id"], acc, res["media_id"], res.get("permalink")))
            db.execute("UPDATE drafts SET status='published', image_path=? WHERE id=?", (img, d["id"]))
            print(f"опубликовано #{d['id']} [{acc}] {res.get('permalink')}")
            # «пост вышел» показывает пульт, отдельного сообщения нет
        except Exception as e:  # noqa: BLE001
            err = str(e)
            from .tg import notify
            if "5258005" in err or "API access blocked" in err:
                # доступ к API закрыт: пост оставляем в очереди, дальше не долбим API
                print(f"API заблокирован, публикация остановлена: {err[:200]}")
                block_flag.write_text((datetime.now(tz) + timedelta(hours=6)).isoformat())
                notify(cfg, f"⛔ Meta заблокировала API (5258005). Посты ждут в очереди, следующая попытка через 6 часов. {err[:200]}")
                db.commit()
                break
            db.execute("UPDATE drafts SET status='failed', error=? WHERE id=?", (err[:500], d["id"]))
            print(f"ошибка #{d['id']}: {e}")
            notify(cfg, f"⚠️ Не опубликовалось #{d['id']} [{acc}]: {err[:300]}")
        db.commit()


# ---------- статистика ----------
def collect_metrics(cfg, db, newer_days=7, older_days=None) -> tuple[int, int]:
    """Снимок просмотров/лайков/ответов для постов за newer_days (или от newer_days до older_days).
    Возвращает (успешно, ошибок). Блок API (5258005) прерывает сбор."""
    q = "SELECT * FROM posts WHERE published_at >= datetime('now', ?)"
    params = [f"-{older_days or newer_days} days"]
    if older_days:
        q += " AND published_at < datetime('now', ?)"
        params.append(f"-{newer_days} days")
    ok = bad = 0
    clients = {}
    for p in list(db.execute(q, params)):
        try:
            c = clients.setdefault(p["account"], client_for(cfg, p["account"]))
            m = c.insights(p["media_id"])
            db.execute("INSERT INTO metrics(post_id,views,likes,replies,reposts,quotes,shares) VALUES(?,?,?,?,?,?,?)",
                       (p["id"], m.get("views"), m.get("likes"), m.get("replies"), m.get("reposts"), m.get("quotes"), m.get("shares")))
            ok += 1
        except Exception as e:  # noqa: BLE001
            if "5258005" in str(e):
                db.commit()
                raise
            bad += 1
            print(f"статистика поста {p['id']}: {str(e)[:150]}")
    db.commit()
    return ok, bad


def cmd_metrics(cfg, args):
    db = get_db(cfg)
    ok, bad = collect_metrics(cfg, db, newer_days=args.days)
    print(f"обновлено постов: {ok}, ошибок: {bad}")


def cmd_report(cfg, args):
    db = get_db(cfg)
    q = """
    SELECT p.account, d.visual_kind, COUNT(*) n, AVG(m.views) views, AVG(m.likes) likes, AVG(m.replies) replies
    FROM posts p JOIN drafts d ON d.id=p.draft_id
    JOIN metrics m ON m.post_id=p.id AND m.taken_at=(SELECT MAX(taken_at) FROM metrics WHERE post_id=p.id)
    WHERE p.published_at >= datetime('now', ?)
    GROUP BY p.account, d.visual_kind ORDER BY p.account
    """
    print(f"{'акк':4}{'визуал':8}{'постов':>7}{'просм.':>9}{'лайки':>7}{'ответы':>8}")
    for r in db.execute(q, (f"-{args.days} days",)):
        print(f"{r['account']:4}{r['visual_kind']:8}{r['n']:>7}{(r['views'] or 0):>9.0f}{(r['likes'] or 0):>7.1f}{(r['replies'] or 0):>8.1f}")
    print("\nПереходы в Telegram смотрите в статистике канала по каждой пригласительной ссылке (accounts.*.tg_link).")


def cmd_refresh_tokens(cfg, args):
    for acc in cfg["accounts"]:
        try:
            cfg["accounts"][acc]["access_token"] = client_for(cfg, acc).refresh_token()
            print(f"{acc}: токен обновлён")
        except Exception as e:  # noqa: BLE001
            print(f"{acc}: {e}")
    save_config(cfg)


# ---------- автоматика ----------
def cmd_tg_setup(cfg, args):
    """Подключает Telegram-бота для одобрения. Сначала напишите своему боту /start."""
    from .tg import api
    me = api(args.token, "getMe")
    ups = api(args.token, "getUpdates")
    chats = [u["message"]["chat"]["id"] for u in ups if u.get("message")]
    if not chats:
        sys.exit(f"Бот @{me['username']} найден, но вы ему ещё не писали. Откройте его в Telegram, нажмите Start и повторите команду.")
    cfg["telegram"] = {"token": args.token, "chat_id": chats[-1]}
    save_config(cfg)
    old = ROOT / "drafts" / "drafts_001.json"  # первая «роботизированная» пачка, заменена drafts_002
    if old.exists():
        db = get_db(cfg)
        for it in json.loads(old.read_text(encoding="utf-8")):
            db.execute("UPDATE drafts SET status='rejected' WHERE status='new' AND text=?", (it["text"].strip(),))
        db.commit()
    api(args.token, "sendMessage", chat_id=chats[-1], text="Готово ✅ Сюда будут приходить посты на одобрение.")
    print(f"Готово: бот @{me['username']}, чат {chats[-1]}")


def _pull_drafts(cfg, db) -> int:
    """Забирает новые пачки: из папки drafts/inbox и из репозитория GitHub (раздел drafts_repo)."""
    import requests
    from .tg import ensure_schema, kv_get, kv_set
    ensure_schema(db)
    added = 0
    inbox = ROOT / "drafts" / "inbox"
    inbox.mkdir(parents=True, exist_ok=True)
    done = ROOT / "drafts" / "imported"
    done.mkdir(exist_ok=True)
    for f in sorted(inbox.glob("*.json")):
        added += _import_batch(db, json.loads(f.read_text(encoding="utf-8")))
        f.replace(done / f.name)
    src = cfg.get("drafts_repo") or {}
    token = src.get("token") or (cfg.get("github") or {}).get("token")
    if src.get("repo") and token:
        h = {"Authorization": f"Bearer {token}", "Accept": "application/vnd.github+json"}
        r = requests.get(f"https://api.github.com/repos/{src['repo']}/contents/{src.get('path', 'drafts')}",
                         headers=h, params={"ref": src.get("branch", "main")}, timeout=30)
        if r.status_code == 200:
            got = set(json.loads(kv_get(db, "pulled_files", "[]")))
            for it in sorted(r.json(), key=lambda x: x["name"]):
                if not it["name"].endswith(".json") or it["sha"] in got:
                    continue
                raw = requests.get(it["url"], headers={**h, "Accept": "application/vnd.github.raw"}, timeout=30)
                raw.raise_for_status()
                (done / it["name"]).write_bytes(raw.content)
                added += _import_batch(db, json.loads(raw.content.decode("utf-8")))
                got.add(it["sha"])
            kv_set(db, "pulled_files", json.dumps(sorted(got)))
            db.commit()
        else:
            print(f"GitHub drafts: {r.status_code} {r.text[:150]}")
    return added


def _api_paused() -> bool:
    flag = ROOT / "api_blocked_until.txt"
    if not flag.exists():
        return False
    try:
        return datetime.now().astimezone() < datetime.fromisoformat(flag.read_text().strip())
    except ValueError:
        return False


def cmd_auto(cfg, args):
    """Всё в одном, раз в 15 минут: забрать пачки → отправить в Telegram → прочитать кнопки → расписание →
    публикация → комменты → цифры через сутки → сводка по понедельникам → утренний план."""
    from .tg import kv_get, kv_set, notify, poll, send_new
    db = get_db(cfg)
    tz = ZoneInfo(cfg.get("timezone", "Europe/Chisinau"))
    now = datetime.now(tz)
    tg_on = bool((cfg.get("telegram") or {}).get("chat_id"))
    steps = []

    def step(name, fn):
        try:
            return fn()
        except Exception as e:  # noqa: BLE001
            steps.append(f"{name}: ошибка {str(e)[:150]}")
            return None

    step("role/hook", lambda: _backfill_role_hook(db))
    n = step("забор пачек", lambda: _pull_drafts(cfg, db))
    if n:
        steps.append(f"новых черновиков и ответов: {n}")
    if tg_on:
        def _tg():
            changed = poll(cfg, db)
            sent = send_new(cfg, db, _render)
            steps.append(f"telegram: отправлено {sent}, решений {changed}")
        step("telegram", _tg)
    if db.execute("SELECT COUNT(*) c FROM drafts WHERE status='approved'").fetchone()["c"]:
        step("расписание", lambda: cmd_schedule(cfg, args))
    args.dry_run = getattr(args, "dry_run", False)
    step("публикация", lambda: cmd_publish_due(cfg, args))
    paused = _api_paused()

    # комменты: раз в час
    from . import comments as cm
    from . import ai_reply
    ai_on = ai_reply.conf(cfg)["enabled"]
    every = int(cfg.get("comments_every_minutes", 15 if ai_on else 60))
    if not paused and cm.due_for_fetch(db, every):
        def _comments():
            new = cm.fetch_new(cfg, db)
            cm.mark_fetched(db)
            if new:
                steps.append(f"новых комментов: {len(new)}")
        step("комменты", _comments)
    if ai_on:
        def _ai():
            r = ai_reply.draft_new(cfg, db)
            if r["drafted"] or r["stopped"]:
                steps.append(f"ответы ИИ: {r['drafted']}" + (f", стоп: {r['stopped']}" if r["stopped"] else ""))
        step("ответы ИИ", _ai)
    else:
        step("комменты в GitHub", lambda: cm.push_pending(cfg, db))
    if tg_on:
        from .tg import send_comments
        step("комменты в Telegram", lambda: send_comments(cfg, db))

    # статистика раз в день, цифры через 24 ч, сводка по понедельникам
    from . import reports
    today = now.date().isoformat()
    # свежие посты (7 дней) каждый час, старые (до 30 дней) раз в день; отметка только при успехе
    last = kv_get(db, "metrics_at")
    if not paused and (not last or datetime.fromisoformat(last) <= datetime.now(tz) - timedelta(minutes=int(cfg.get("metrics_every_minutes", 60)))):
        def _metrics():
            from .accounts import sync_all
            errs = sync_all(cfg, db)  # профиль + все посты аккаунтов, цифры как в приложении Threads
            ok, bad = (1, 0) if not errs else collect_metrics(cfg, db, newer_days=7)
            if errs:
                steps.append("профили: " + "; ".join(errs))
            if ok or not bad:
                kv_set(db, "metrics_at", datetime.now(tz).isoformat())
                db.commit()
            if bad:
                steps.append(f"статистика: {ok} ок, {bad} ошибок")
        step("статистика", _metrics)
    if not paused and kv_get(db, "metrics_day") != today and now.hour >= 6:
        def _old():
            ok, bad = collect_metrics(cfg, db, newer_days=7, older_days=30)
            if ok or not bad:
                kv_set(db, "metrics_day", today)
                db.commit()
        step("статистика старых", _old)
    if tg_on and reports.is_monday_due(cfg, db):
        def _week():
            reports.send_weekly(cfg, db)
            reports.mark_monday(cfg, db)
        step("сводка", _week)
    if tg_on:
        from . import pult, topics
        step("темы", lambda: topics.setup(cfg, db))
        step("пульт", lambda: pult.refresh(cfg, db))
    print(f"[{datetime.now(tz):%d.%m %H:%M}] " + ("; ".join(steps) or "ок"), flush=True)


def _start_web(cfg):
    """Веб-интерфейс в фоне того же процесса: http://127.0.0.1:8765"""
    import threading
    from .web import serve
    port = int(cfg.get("web_port", 8765))
    th = threading.Thread(target=serve, args=(port,), daemon=True)
    th.start()
    return port


def cmd_web(cfg, args):
    """Только веб-интерфейс (без Telegram и публикации), для проверки."""
    from .web import serve
    port = int(cfg.get("web_port", 8765))
    print(f"Открой http://127.0.0.1:{port}/")
    serve(port)


def cmd_run(cfg, args):
    """Постоянный процесс: long-polling Telegram (кнопки срабатывают сразу), веб-интерфейс
    и полный цикл auto раз в 15 минут. Второй экземпляр сразу выходит."""
    import socket, time
    from .tg import poll, send_new
    lock = socket.socket()
    try:
        lock.bind(("127.0.0.1", 47613))
    except OSError:
        return  # already running
    try:
        _start_web(cfg)
    except Exception as e:  # noqa: BLE001
        print(f"[run] веб-интерфейс не запустился: {e}", flush=True)
    last_full = 0.0
    while True:
        try:
            cfg = load_config()
            if time.time() - last_full >= 900:
                cmd_auto(cfg, args); last_full = time.time()
            if (cfg.get("telegram") or {}).get("chat_id"):
                db = get_db(cfg)
                from .tg import kv_get
                kicked = kv_get(db, "kick") == "1"
                if kicked:
                    db.execute("DELETE FROM kv WHERE key='kick'"); db.commit()
                if poll(cfg, db, wait=25) or kicked:
                    if db.execute("SELECT COUNT(*) c FROM drafts WHERE status='approved'").fetchone()["c"]:
                        cmd_schedule(cfg, args)
                    send_new(cfg, db, _render)
                    args.dry_run = getattr(args, "dry_run", False)
                    cmd_publish_due(cfg, args)  # для «🚀 сейчас»
                    from . import pult
                    pult.refresh(cfg, db)
            else:
                time.sleep(30)
                db = get_db(cfg)
                if db.execute("SELECT value FROM kv WHERE key='kick'").fetchone():
                    db.execute("DELETE FROM kv WHERE key='kick'"); db.commit()
                    cmd_schedule(cfg, args); cmd_publish_due(cfg, args)
        except Exception as e:  # noqa: BLE001
            print(f"[run] error: {e}", flush=True); time.sleep(30)


def cmd_set_drafts_repo(cfg, args):
    """Откуда брать пачки от Claude: python -m bot.cli set-drafts-repo ник/THREADS-DRAFTS [токен]"""
    import requests
    token = args.token or (cfg.get("github") or {}).get("token")
    repo = args.repo.strip().removeprefix("https://github.com/").strip("/")
    r = requests.get(f"https://api.github.com/repos/{repo}",
                     headers={"Authorization": f"Bearer {token}", "Accept": "application/vnd.github+json"}, timeout=30)
    if r.status_code != 200:
        sys.exit(f"GitHub не пустил в {repo}: {r.status_code}. Добавьте репозиторий в настройки токена.")
    cfg["drafts_repo"] = {"repo": repo, "branch": r.json().get("default_branch", "main"), "path": "drafts"}
    if args.token:
        cfg["drafts_repo"]["token"] = args.token
    save_config(cfg)
    print(f"Готово: пачки буду забирать из {repo}/drafts")


def cmd_check(cfg, args):
    for acc in cfg["accounts"]:
        try:
            print(acc, client_for(cfg, acc).publishing_limit())
        except Exception as e:  # noqa: BLE001
            print(acc, "ошибка:", e)


def main():
    ap = argparse.ArgumentParser(prog="bot")
    sp = ap.add_subparsers(dest="cmd", required=True)
    p = sp.add_parser("add-idea"); p.add_argument("text"); p.add_argument("--url"); p.add_argument("--author")
    p.add_argument("--likes", type=int, default=0); p.add_argument("--replies", type=int, default=0)
    p = sp.add_parser("import-ideas"); p.add_argument("file")
    p = sp.add_parser("search"); p.add_argument("queries", nargs="+"); p.add_argument("--account", default="A")
    p.add_argument("--type", default="TOP", choices=["TOP", "RECENT"])
    p = sp.add_parser("generate"); p.add_argument("--account", required=True, choices=["A", "B", "C"])
    p.add_argument("--n", type=int, default=3); p.add_argument("--ideas", type=int, default=5)
    p.add_argument("--market", help="тикеры через запятую для свежих цифр, напр. XAUUSD,EURUSD")
    p = sp.add_parser("import-drafts"); p.add_argument("file")
    p = sp.add_parser("export-context"); p.add_argument("--out", default="context.md")
    p.add_argument("--market", default="XAUUSD,EURUSD,GBPUSD,USDJPY,XAGUSD", help="тикеры для свежих цифр")
    p = sp.add_parser("set-token"); p.add_argument("account", choices=["A", "B", "C"]); p.add_argument("token")
    p = sp.add_parser("set-github"); p.add_argument("repo"); p.add_argument("token")
    p = sp.add_parser("tg-setup"); p.add_argument("token")
    p = sp.add_parser("set-drafts-repo"); p.add_argument("repo"); p.add_argument("token", nargs="?")
    p = sp.add_parser("auto"); p.add_argument("--dry-run", action="store_true")
    p = sp.add_parser("run"); p.add_argument("--dry-run", action="store_true")
    sp.add_parser("web")
    p = sp.add_parser("review"); p.add_argument("--account"); p.add_argument("--render", action="store_true")
    p = sp.add_parser("approve"); p.add_argument("ids", nargs="+", type=int)
    p = sp.add_parser("reject"); p.add_argument("ids", nargs="+", type=int)
    p = sp.add_parser("edit"); p.add_argument("id", type=int); p.add_argument("text")
    sp.add_parser("schedule")
    p = sp.add_parser("publish-due"); p.add_argument("--dry-run", action="store_true")
    p = sp.add_parser("metrics"); p.add_argument("--days", type=int, default=7)
    p = sp.add_parser("report"); p.add_argument("--days", type=int, default=7)
    sp.add_parser("refresh-tokens")
    sp.add_parser("check")
    args = ap.parse_args()
    cfg = load_config()
    globals()["cmd_" + args.cmd.replace("-", "_")](cfg, args)


if __name__ == "__main__":
    main()
