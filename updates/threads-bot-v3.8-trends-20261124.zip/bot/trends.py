"""Темы дня для постов: что сейчас обсуждают трейдеры (бесплатно, без ключей).

Источники (проверены 24.11.2026 запросом из Python бота на ПК):
- ApeWisdom: упоминания тикеров на Reddit за 24 ч и сутки назад
  https://apewisdom.io/api/v1.0/filter/all-stocks/page/1
- Stocktwits trending: тикеры в тренде у трейдеров с короткой причиной
  https://api.stocktwits.com/api/2/trending/symbols.json

Что делает collect() (из auto не чаще раза в `trends.every_minutes`, по умолчанию 180 мин):
- берёт оба источника, источник с ошибкой пропускает и пишет причину в notes;
- сохраняет trends/latest.json и trends/trends_<дата>_<ЧЧММ>.json рядом с ботом;
- если в config.json есть раздел github (репозиторий картинок с токеном), кладёт туда trends/latest.json,
  чтобы утренняя задача Claude брала темы из реальных данных (облаку эти сайты закрыты).
Ничего не публикует и черновиков не создаёт.
"""
import base64
import html
import json
from datetime import datetime, timedelta, timezone
from pathlib import Path

import requests

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "trends"
UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
                    "Chrome/124.0 Safari/537.36", "Accept": "application/json"}
APE = "https://apewisdom.io/api/v1.0/filter/all-stocks/page/1"
STW = "https://api.stocktwits.com/api/2/trending/symbols.json"


def conf(cfg) -> dict:
    t = cfg.get("trends") or {}
    return {"enabled": t.get("enabled", True), "every": int(t.get("every_minutes", 180)),
            "top": int(t.get("top", 15)), "sources": t.get("sources") or ["apewisdom", "stocktwits"],
            "push": t.get("push", True)}


def _int(v):
    try:
        return int(v)
    except (TypeError, ValueError):
        return None


def apewisdom(top=15) -> list[dict]:
    r = requests.get(APE, headers=UA, timeout=20)
    r.raise_for_status()
    out = []
    for x in (r.json().get("results") or [])[:top]:
        m, m0 = _int(x.get("mentions")), _int(x.get("mentions_24h_ago"))
        out.append({"ticker": x.get("ticker"), "name": html.unescape(x.get("name") or ""), "mentions": m, "mentions_24h_ago": m0,
                    "growth_pct": round((m - m0) / m0 * 100) if m is not None and m0 else None,
                    "rank": _int(x.get("rank")), "rank_24h_ago": _int(x.get("rank_24h_ago")),
                    "upvotes": _int(x.get("upvotes"))})
    return out


def stocktwits(top=15) -> list[dict]:
    r = requests.get(STW, headers=UA, timeout=20)
    if r.status_code == 403:
        raise RuntimeError("403 от Cloudflare (Stocktwits режет скрипты), пропускаю")
    r.raise_for_status()
    out = []
    for x in (r.json().get("symbols") or [])[:top]:
        info = x.get("trends") or {}
        why = info.get("summary") or ""  # причина тренда, проверено 24.11: trends.summary
        out.append({"ticker": x.get("symbol"), "name": x.get("title"), "score": x.get("trending_score"),
                    "why": why.strip()[:400], "why_at": info.get("summary_at"), "watchers": _int(x.get("watchlist_count"))})
    return out


SOURCES = {"apewisdom": apewisdom, "stocktwits": stocktwits}


def collect(cfg) -> dict:
    c = conf(cfg)
    data = {"at_utc": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"), "notes": []}
    for name in c["sources"]:
        fn = SOURCES.get(name)
        if not fn:
            continue
        try:
            data[name] = fn(c["top"])
        except Exception as e:  # noqa: BLE001
            data[name] = []
            data["notes"].append(f"{name}: {type(e).__name__} {str(e)[:150]}")
    OUT.mkdir(exist_ok=True)
    body = json.dumps(data, ensure_ascii=False, indent=1)
    (OUT / "latest.json").write_text(body, encoding="utf-8")
    (OUT / f"trends_{datetime.now():%Y%m%d_%H%M}.json").write_text(body, encoding="utf-8")
    return data


def push(cfg, data) -> str:
    """trends/latest.json в репозиторий картинок (раздел github в config.json). Токен уже есть у бота."""
    gh = cfg.get("github") or {}
    if not (gh.get("repo") and gh.get("token")):
        return "нет раздела github, в репозиторий не кладу"
    repo, branch = gh["repo"], gh.get("branch", "main")
    api = f"https://api.github.com/repos/{repo}/contents/trends/latest.json"
    h = {"Authorization": f"Bearer {gh['token']}", "Accept": "application/vnd.github+json"}
    body = {"message": f"trends {data['at_utc']}", "branch": branch,
            "content": base64.b64encode(json.dumps(data, ensure_ascii=False, indent=1).encode()).decode()}
    old = requests.get(api, headers=h, params={"ref": branch}, timeout=30)
    if old.status_code == 200:
        body["sha"] = old.json()["sha"]
    r = requests.put(api, headers=h, json=body, timeout=60)
    if r.status_code >= 300:
        raise RuntimeError(f"GitHub не принял trends: {r.status_code} {r.text[:150]}")
    return f"{repo}/trends/latest.json"


def due(cfg, db) -> bool:
    from .tg import kv_get
    c = conf(cfg)
    if not c["enabled"]:
        return False
    last = kv_get(db, "trends_at")
    return not last or datetime.fromisoformat(last) <= datetime.now(timezone.utc) - timedelta(minutes=c["every"])


def run(cfg, db) -> str:
    """Из auto: собрать, сохранить, выложить. Возвращает строку для лога."""
    from .tg import kv_set
    data = collect(cfg)
    kv_set(db, "trends_at", datetime.now(timezone.utc).isoformat())
    db.commit()
    where = ""
    if conf(cfg)["push"]:
        try:
            where = ", " + push(cfg, data)
        except Exception as e:  # noqa: BLE001
            where = f", в GitHub не ушло: {str(e)[:100]}"
    n = {k: len(data.get(k) or []) for k in SOURCES}
    return "темы дня: " + ", ".join(f"{k} {v}" for k, v in n.items()) + where + \
        ("; " + "; ".join(data["notes"]) if data["notes"] else "")


def text(data) -> str:
    """Читаемая сводка для командной строки и контекста."""
    out = [f"Темы дня, {data.get('at_utc')} UTC"]
    if data.get("apewisdom"):
        out.append("\nReddit (ApeWisdom), упоминания за 24 ч:")
        for x in data["apewisdom"]:
            g = f", {x['growth_pct']:+d}% к вчера" if x.get("growth_pct") is not None else ""
            out.append(f"- {x['ticker']} {x['name']}: {x['mentions']} (сутки назад {x['mentions_24h_ago']}{g}), "
                       f"место {x['rank']} (было {x['rank_24h_ago']})")
    if data.get("stocktwits"):
        out.append("\nStocktwits trending:")
        for x in data["stocktwits"]:
            out.append(f"- {x['ticker']} {x['name']}: score {x['score']}" + (f". {x['why']}" if x.get("why") else ""))
    for n in data.get("notes") or []:
        out.append(f"(!) {n}")
    return "\n".join(out)
