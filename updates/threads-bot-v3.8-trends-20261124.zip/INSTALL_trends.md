# v3.8: темы дня (ApeWisdom + Stocktwits)
База v3.7. Меняются bot/cli.py, новый bot/trends.py. config.json и база не меняются.
- auto раз в 3 часа собирает темы → trends/latest.json рядом с ботом и в репозиторий картинок (раздел github) trends/latest.json.
- python -m bot.cli trends — показать темы, ничего не публикует (--push ещё и в GitHub).
- export-context теперь включает темы дня.
- Необязательно в config.json: "trends": {"enabled": true, "every_minutes": 180, "top": 15, "push": true}.
- Stocktwits отвечает только с браузерным User-Agent (без него 403 Cloudflare, проверено 24.11). Если начнёт резать, бот пропустит его и напишет причину в лог.
Откат: вернуть bot/cli.py из backup_20261124_v37, удалить bot/trends.py.
