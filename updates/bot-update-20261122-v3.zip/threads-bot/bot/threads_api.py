"""Минимальный клиент официального Threads API (graph.threads.net)."""
import time
import requests

BASE = "https://graph.threads.net/v1.0"


class ThreadsError(RuntimeError):
    pass


class ThreadsClient:
    def __init__(self, user_id: str, access_token: str):
        self.user_id = user_id
        self.token = access_token

    def _req(self, method: str, path: str, **params):
        params["access_token"] = self.token
        try:
            r = requests.request(method, f"{BASE}/{path}", params=params, timeout=60)
        except requests.RequestException as e:
            # без адреса запроса: в нём токен
            raise ThreadsError(f"нет связи с Threads ({type(e).__name__})") from None
        data = r.json() if r.content else {}
        if r.status_code >= 400 or "error" in data:
            raise ThreadsError(f"{r.status_code}: {data.get('error', data)}")
        return data

    # --- публикация ---
    def _container(self, **params) -> str:
        return self._req("POST", f"{self.user_id}/threads", **params)["id"]

    def _wait_ready(self, container_id: str, tries: int = 20):
        for _ in range(tries):
            st = self._req("GET", container_id, fields="status,error_message")
            if st.get("status") == "FINISHED":
                return
            if st.get("status") in ("ERROR", "EXPIRED"):
                raise ThreadsError(f"контейнер {container_id}: {st}")
            time.sleep(3)
        raise ThreadsError(f"контейнер {container_id} не готов")

    def _publish(self, container_id: str) -> dict:
        self._wait_ready(container_id)
        media_id = self._req("POST", f"{self.user_id}/threads_publish", creation_id=container_id)["id"]
        info = self._req("GET", media_id, fields="id,permalink")
        return {"media_id": media_id, "permalink": info.get("permalink")}

    def post_text(self, text: str, topic: str | None = None) -> dict:
        extra = {"topic_tag": topic} if topic else {}
        return self._publish(self._container(media_type="TEXT", text=text, **extra))

    def post_image(self, text: str, image_url: str, topic: str | None = None) -> dict:
        """image_url должен быть публично доступен (JPEG/PNG до 8 МБ)."""
        extra = {"topic_tag": topic} if topic else {}
        return self._publish(self._container(media_type="IMAGE", image_url=image_url, text=text, **extra))

    def post_carousel(self, text: str, image_urls: list[str], topic: str | None = None) -> dict:
        children = [self._container(media_type="IMAGE", image_url=u, is_carousel_item="true") for u in image_urls]
        for c in children:
            self._wait_ready(c)
        extra = {"topic_tag": topic} if topic else {}
        return self._publish(self._container(media_type="CAROUSEL", children=",".join(children), text=text, **extra))

    def reply(self, media_id: str, text: str) -> dict:
        return self._publish(self._container(media_type="TEXT", text=text, reply_to_id=media_id))

    def conversation(self, media_id: str, max_pages: int = 5) -> list[dict]:
        """Все ответы под постом (все уровни). Нужно разрешение threads_read_replies."""
        out, params = [], {"fields": "id,text,username,timestamp,is_reply_owned_by_me,replied_to", "reverse": "false"}
        path = f"{media_id}/conversation"
        for _ in range(max_pages):
            data = self._req("GET", path, **params)
            out += data.get("data", [])
            after = ((data.get("paging") or {}).get("cursors") or {}).get("after")
            if not after or not (data.get("paging") or {}).get("next"):
                break
            params["after"] = after
        return out

    # --- статистика и лимиты ---
    def insights(self, media_id: str) -> dict:
        data = self._req("GET", f"{media_id}/insights", metric="views,likes,replies,reposts,quotes,shares")
        return {m["name"]: m["values"][0]["value"] for m in data.get("data", [])}

    def user_insights(self, since: int, until: int) -> dict:
        """Статистика профиля как в приложении Threads (Статистика → Обзор): просмотры по дням и итоги за период."""
        data = self._req("GET", f"{self.user_id}/threads_insights", since=since, until=until,
                         metric="views,likes,replies,reposts,quotes,followers_count")
        out = {"series": []}
        for m in data.get("data", []):
            if m.get("values"):
                out["series"] = [{"day": v.get("end_time", "")[:10], "value": v.get("value") or 0} for v in m["values"]] \
                    if m["name"] == "views" else out["series"]
                if m["name"] == "views":
                    out["views"] = sum(v.get("value") or 0 for v in m["values"])
            if m.get("total_value") is not None:
                out[m["name"]] = (m["total_value"] or {}).get("value")
        return out

    def list_threads(self, limit: int = 50) -> list[dict]:
        """Все посты аккаунта (и опубликованные руками в приложении)."""
        data = self._req("GET", f"{self.user_id}/threads", limit=limit,
                         fields="id,text,timestamp,permalink,media_type,is_quote_post")
        return data.get("data", [])

    def publishing_limit(self) -> dict:
        return self._req("GET", f"{self.user_id}/threads_publishing_limit", fields="quota_usage,config")

    # --- поиск (нужно одобрение threads_keyword_search, иначе ищет только по своим постам) ---
    def keyword_search(self, q: str, search_type: str = "TOP", limit: int = 50) -> list[dict]:
        data = self._req("GET", "keyword_search", q=q, search_type=search_type, limit=limit,
                         fields="id,text,media_type,permalink,timestamp,username")
        return data.get("data", [])

    # --- токен ---
    def refresh_token(self) -> str:
        r = requests.get("https://graph.threads.net/refresh_access_token",
                         params={"grant_type": "th_refresh_token", "access_token": self.token}, timeout=30)
        r.raise_for_status()
        self.token = r.json()["access_token"]
        return self.token
