"""Действия над черновиками и комментами. Общие для Telegram-бота и веб-интерфейса,
чтобы кнопки в обоих местах делали ровно одно и то же."""
import random
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo


class ActionError(RuntimeError):
    pass


def _tz(cfg):
    return ZoneInfo(cfg.get("timezone", "Europe/Chisinau"))


def _draft(db, did):
    row = db.execute("SELECT * FROM drafts WHERE id=?", (int(did),)).fetchone()
    if not row:
        raise ActionError(f"нет поста #{did}")
    return row


# ---------- посты ----------
def approve(cfg, db, did):
    d = _draft(db, did)
    if d["status"] not in ("new", "held", "failed"):
        raise ActionError(f"#{did} уже: {d['status']}")
    db.execute("UPDATE drafts SET status='approved', error=NULL WHERE id=?", (d["id"],))
    db.commit()


def reject(cfg, db, did):
    """Отклонить и сразу подставить замену из запаса того же аккаунта."""
    d = _draft(db, did)
    if d["status"] == "published":
        raise ActionError(f"#{did} уже опубликован")
    db.execute("UPDATE drafts SET status='rejected', scheduled_at=NULL WHERE id=?", (d["id"],))
    db.commit()
    from .setups import is_setup
    if d["status"] == "new" and not is_setup(d):  # для сетапа замену из запаса не берём
        from .tg import replace_rejected
        replace_rejected(cfg, db, d["id"])


def edit(cfg, db, did, text):
    from .style import check_text
    d = _draft(db, did)
    if d["status"] == "published":
        raise ActionError(f"#{did} уже опубликован, текст не поменять")
    text = (text or "").strip()
    from .setups import check as setup_check, is_setup
    problems = setup_check(text) if is_setup(d) else check_text(text)
    if problems:
        raise ActionError("не прошло стоп-лист: " + ", ".join(problems))
    db.execute("UPDATE drafts SET text=? WHERE id=?", (text, d["id"]))
    db.commit()


def move(cfg, db, did, hours=2.0):
    """Сдвинуть запланированный пост на N часов; если вылез за окно публикации, на утро."""
    d = _draft(db, did)
    if d["status"] != "scheduled" or not d["scheduled_at"]:
        raise ActionError(f"#{did} не в расписании")
    tz = _tz(cfg)
    start_h, end_h = cfg.get("posting_window", [9, 23])
    t = max(datetime.fromisoformat(d["scheduled_at"]), datetime.now(tz)) + timedelta(hours=hours)
    if t.hour >= end_h or t.hour < start_h:
        day = t.date() if t.hour < start_h else t.date() + timedelta(days=1)
        t = datetime(day.year, day.month, day.day, start_h, random.randint(0, 50), tzinfo=tz)
    db.execute("UPDATE drafts SET scheduled_at=? WHERE id=?", (t.isoformat(), d["id"]))
    db.commit()
    return t


def publish_now(cfg, db, did):
    """Поставить пост на «сейчас». Выйдет в ближайший проход, но не раньше чем через час после прошлого поста аккаунта."""
    d = _draft(db, did)
    if d["status"] not in ("scheduled", "approved", "held", "new", "failed"):
        raise ActionError(f"#{did} уже: {d['status']}")
    now = datetime.now(_tz(cfg)).isoformat()
    db.execute("UPDATE drafts SET status='scheduled', scheduled_at=?, error=NULL WHERE id=?", (now, d["id"]))
    db.commit()


def hold(cfg, db, did):
    """Снять с расписания (пост остаётся, его можно вернуть)."""
    d = _draft(db, did)
    if d["status"] not in ("scheduled", "approved"):
        raise ActionError(f"#{did} не в очереди")
    db.execute("UPDATE drafts SET status='held', scheduled_at=NULL WHERE id=?", (d["id"],))
    db.commit()


def unhold(cfg, db, did):
    """Вернуть снятый пост в очередь: встанет в ближайший свободный слот."""
    d = _draft(db, did)
    if d["status"] != "held":
        raise ActionError(f"#{did} не снят")
    db.execute("UPDATE drafts SET status='approved' WHERE id=?", (d["id"],))
    db.commit()


# ---------- комменты ----------
def _comment(db, cid):
    row = db.execute("SELECT * FROM comments WHERE id=?", (str(cid),)).fetchone()
    if not row:
        raise ActionError("нет такого коммента")
    return row


def skip_comment(cfg, db, cid):
    _comment(db, cid)
    db.execute("UPDATE comments SET status='skipped' WHERE id=?", (str(cid),))
    db.commit()


def set_reply(cfg, db, cid, text, status="drafted"):
    from .style import check_text
    c = _comment(db, cid)
    if c["status"] == "answered":
        raise ActionError("на этот коммент уже ответили")
    text = (text or "").strip()
    if not text:
        raise ActionError("пустой ответ")
    problems = check_text(text)
    if problems:
        raise ActionError("не прошло стоп-лист: " + ", ".join(problems))
    db.execute("UPDATE comments SET reply_text=?, status=?, error=NULL WHERE id=?", (text, status, str(cid)))
    db.commit()


def reject_reply(cfg, db, cid):
    """Ответ не понравился: коммент снова ждёт, Claude утром напишет другой вариант."""
    _comment(db, cid)
    db.execute("UPDATE comments SET status='new', reply_text=NULL WHERE id=?", (str(cid),))
    db.commit()


def approve_reply(cfg, db, cid, text=None):
    """Одобрить ответ и сразу опубликовать его под комментом."""
    if text is not None:
        set_reply(cfg, db, cid, text)
    c = _comment(db, cid)
    if c["status"] == "answered":
        raise ActionError("уже отвечено")
    if not c["reply_text"]:
        raise ActionError("ответа ещё нет")
    from .cli import client_for
    try:
        res = client_for(cfg, c["account"]).reply(c["id"], c["reply_text"])
    except Exception as e:  # noqa: BLE001
        db.execute("UPDATE comments SET status='failed', error=? WHERE id=?", (str(e)[:400], c["id"]))
        db.commit()
        raise ActionError(f"Threads не принял ответ: {str(e)[:200]}") from e
    db.execute("UPDATE comments SET status='answered', reply_media_id=? WHERE id=?", (res.get("media_id"), c["id"]))
    db.commit()
    return res
