"""Торговые сетапы для C (@serbovcrp) из Telegram-бота Syndicate.

Threads сам уровни не считает. Единственный источник — бот на Cloudflare:
GET <url>?key=<SIGNALS_KEY>. Ключ лежит только в config.json на ПК (раздел "signals"),
в посты, логи и сообщения он не попадает.

Формат ответа (документ «Логика сетапов Syndicate», раздел «Синхронизация с Threads»):
    #syndicate;<unix_now>
    key;state;side;entry;stop;tp1;tp2;partial;valid_until;flat_before;ref_price;ref_time
key = <дата>/<id поста>, state = waiting | open | tp1 | исход закрытого (виден 3 дня), время unix UTC.

Что делает sync() (раз в проход auto, по умолчанию раз в 15 минут):
- новый сетап в waiting → черновик «план» на одобрение в Telegram;
- waiting → open → ответ под постом «вход сработал»;
- open → tp1 → ответ «цель 1 взята, стоп в безубытке»;
- любой другой state → ответ «итог».
Все черновики идут через обычное одобрение ✅❌✏️, сам бот ничего не публикует без кнопки.
"""
import json
import re
from datetime import datetime, timezone
from zoneinfo import ZoneInfo

import requests

DEFAULT_URL = "https://tg-channel-bot.jznb1111.workers.dev/signals"
FIELDS = ["key", "state", "side", "entry", "stop", "tp1", "tp2", "partial",
          "valid_until", "flat_before", "ref_price", "ref_time"]
LIVE = ("waiting", "open", "tp1")
DISCLAIMER = "Разбор, а не инвестиционная рекомендация"
LIMIT = 300  # решение Ильи 24.11: посты сетапов в Threads до 300 знаков (лимит самого Threads 500)

# Исходы закрытого сетапа — как в tracker.js (OUTCOME_RU), репозиторий tg-channel-content, сверено 24.11 (7de1987).
# Незнакомый исход бот в пост не превращает, а пишет Илье.
OUTCOMES = {
    "sl": "stop", "tp2": "tp2", "tp1_be": "be", "not_triggered": "nofill", "cancelled": "cancel",
    "missed": "skip", "closed_news": "flat", "closed_time": "time",
}


class SignalsError(RuntimeError):
    pass


def conf(cfg) -> dict:
    s = cfg.get("signals") or {}
    return {"key": (s.get("key") or "").strip(), "url": s.get("url") or DEFAULT_URL,
            "account": s.get("account") or "C", "topic": s.get("topic") or None,
            # текст и график из пачки Telegram (репозиторий приватный: нужен read-only токен GitHub)
            "repo": s.get("repo") or "jznb1111-lab/tg-channel-content", "branch": s.get("branch") or "main",
            # свой токен или уже имеющийся токен бота (drafts_repo / github), если у него есть доступ к репозиторию
            "github_token": (s.get("github_token") or (cfg.get("drafts_repo") or {}).get("token")
                             or (cfg.get("github") or {}).get("token") or "").strip(),
            "charts_url": s.get("charts_url") or "https://tg-channel-bot.jznb1111.workers.dev"}


def enabled(cfg) -> bool:
    c = conf(cfg)
    return bool(c["key"]) and c["account"] in (cfg.get("accounts") or {})


# ---------- чтение и разбор ----------
def fetch(cfg) -> str:
    c = conf(cfg)
    try:
        r = requests.get(c["url"], params={"key": c["key"]}, timeout=30)
    except requests.RequestException as e:
        raise SignalsError(f"нет связи с ботом сетапов ({type(e).__name__})") from None  # без адреса: в нём ключ
    if r.status_code == 404:
        raise SignalsError("бот сетапов ответил 404: неверный ключ в config.json (signals.key) или адрес")
    if r.status_code >= 400:
        raise SignalsError(f"бот сетапов ответил {r.status_code}")
    return r.text


def _num(s):
    s = (s or "").strip()
    if not s:
        return None
    try:
        float(s)
    except ValueError:
        raise SignalsError(f"не число: {s!r}") from None
    return s  # как пришло, без округлений


def parse(text: str) -> tuple[int | None, list[dict]]:
    """Возвращает (unix_now из заголовка, строки). Битые строки пропускает с ошибкой в поле _error."""
    lines = [l.strip() for l in (text or "").splitlines() if l.strip()]
    if not lines or not lines[0].startswith("#syndicate"):
        raise SignalsError("ответ не похож на /signals (нет заголовка #syndicate)")
    head = lines[0].split(";")
    now = int(head[1]) if len(head) > 1 and head[1].strip().isdigit() else None
    rows = []
    for l in lines[1:]:
        if l.startswith("#"):
            continue
        parts = l.split(";")
        if len(parts) < len(FIELDS):
            rows.append({"_error": f"мало полей ({len(parts)})", "_raw_key": parts[0]})
            continue
        r = dict(zip(FIELDS, (p.strip() for p in parts)))
        try:
            for k in ("entry", "stop", "tp1", "tp2", "partial", "ref_price"):
                r[k] = _num(r[k])
            for k in ("valid_until", "flat_before", "ref_time"):
                r[k] = int(r[k]) if r[k].isdigit() and int(r[k]) > 0 else None
            r["state"] = r["state"].lower()
            r["side"] = r["side"].lower()
            if r["side"] not in ("long", "short") or not (r["key"] and r["entry"] and r["stop"] and r["tp1"]):
                raise SignalsError("нет key/side/entry/stop/tp1")
            e, s, t = float(r["entry"]), float(r["stop"]), float(r["tp1"])
            if not ((r["side"] == "short" and s > e > t) or (r["side"] == "long" and s < e < t)):
                raise SignalsError("уровни не по порядку стоп/вход/цель")
        except SignalsError as ex:
            rows.append({"_error": str(ex), "_raw_key": parts[0]})
            continue
        rows.append(r)
    return now, rows


# ---------- тексты ----------
def _t(cfg, ts):
    tz = ZoneInfo(cfg.get("timezone", "Europe/Chisinau"))
    return datetime.fromtimestamp(ts, timezone.utc).astimezone(tz)


def _part(p):
    try:
        x = float(p) if p else 0.5
    except ValueError:
        x = 0.5
    return "половину" if abs(x - 0.5) < 1e-9 else f"{round(x * 100)}%"


def text_plan(cfg, r) -> str:
    sell = r["side"] == "short"
    lines = [f"📊 Золото: план на {'продажу' if sell else 'покупку'}", "",
             f"{'Продажа' if sell else 'Покупка'} от {r['entry']} (лимитный ордер)", f"Стоп {r['stop']}"]
    if r.get("tp2"):
        lines += [f"Цель 1: {r['tp1']}, закрываем {_part(r['partial'])}, стоп на вход", f"Цель 2: {r['tp2']}"]
    else:
        lines += [f"Цель {r['tp1']}"]
    lines.append("")
    if r.get("valid_until"):
        lines.append(f"Действует до {_t(cfg, r['valid_until']):%H:%M %d.%m}")
    if r.get("flat_before"):
        goal = "цель 1" if r.get("tp2") else "цель"
        lines.append(f"📌 Не взяли {goal} к {_t(cfg, r['flat_before']):%H:%M %d.%m}: закрываем до новостей")
    lines += ["Риск не больше 1% депозита", "", DISCLAIMER]
    text = "\n".join(lines)
    if len(text) > LIMIT:  # длинные цены: сначала убираем строку риска
        text = text.replace("Риск не больше 1% депозита\n", "")
    return text


def text_event(cfg, r, kind) -> str | None:
    if kind == "open":
        body = f"Вход по {r['entry']} сработал, позиция открыта\nСтоп {r['stop']}, цель 1 {r['tp1']}"
    elif kind == "tp1":
        rest = f"\nОстаток держим до цели 2: {r['tp2']}" if r.get("tp2") else ""
        body = (f"Цель 1 ({r['tp1']}) взята, {_part(r['partial'])} закрыли\n"
                f"Стоп остатка перенесли на цену входа {r['entry']}" + rest)
    else:
        o = OUTCOMES.get(kind)
        body = {
            "stop": f"Итог: сработал стоп {r['stop']}\nПлан не отработал, сделка закрыта с убытком в пределах риска",
            "tp2": f"Итог: взята цель 2 ({r['tp2']})\nОбе части закрыты по плану" if r.get("tp2")
                   else f"Итог: взята цель {r['tp1']}, сделка закрыта по плану",
            "be": f"Итог: цель 1 ({r['tp1']}) взята, остаток закрылся на цене входа {r['entry']}",
            "nofill": f"Итог: цена не дошла до входа {r['entry']}, план не сработал и снят",
            "cancel": "Итог: план отменён до входа, сделки не было",
            "flat": "Итог: позицию закрыли по рынку перед новостями, как и планировали",
            "time": "Итог: сделку закрыли по времени",
            "skip": f"Итог: к моменту публикации цена уже была за входом {r['entry']}, сделки не было",
        }.get(o)
        if body is None:
            return None
    return body + "\n\n" + DISCLAIMER


# стоп-лист без запретов на уровни входа/стопа/целей: сетапы на C — исключение, решение Ильи 24.11
_SIGNAL_OK = (r"\btp\s*\d", r"тейк\s*\d", r"entry\b", r"вход\s*[:\-]",
              r"(покупай|закупай|бери|берите|продавай)\w*\s+\w+\s+(сейчас|сегодня)")


def check(text: str) -> list[str]:
    from .style import check_text
    out = [p for p in check_text(text) if p not in _SIGNAL_OK]
    if len(text) > LIMIT:
        out.append(f"длиннее {LIMIT} знаков (решение Ильи для сетапов)")
    return out


def is_setup(d) -> bool:
    try:
        return bool(json.loads(d["visual_spec"] or "{}").get("setup_key"))
    except (ValueError, KeyError, IndexError, TypeError):
        return False


# ---------- состояние и черновики ----------
def _kv(db, k, default=None):
    row = db.execute("SELECT value FROM kv WHERE key=?", (k,)).fetchone()
    return json.loads(row["value"]) if row else default


def _kv_set(db, k, v):
    db.execute("INSERT OR REPLACE INTO kv(key,value) VALUES(?,?)", (k, json.dumps(v, ensure_ascii=False)))


def _add_draft(cfg, db, r, kind, text, reply_to=None, image_url=None, image_path=None, source="шаблон") -> int | None:
    c = conf(cfg)
    probs = check(text)
    spec = {"kind": "none", "topic": c["topic"], "role": "доверие", "hook": "сетап",
            "setup_key": r["key"], "setup_event": kind, "setup_source": source}
    if reply_to:
        spec["reply_to_draft"] = reply_to
    if image_url:
        spec["image_url"] = image_url
    cur = db.execute("INSERT INTO drafts(account,text,visual_kind,visual_spec,image_path,status,error) VALUES(?,?,?,?,?,?,?)",
                     (c["account"], text, "tg_chart" if image_url else "none", json.dumps(spec, ensure_ascii=False),
                      image_path, "rejected" if probs else "new", "; ".join(probs) or None))
    return None if probs else cur.lastrowid


# ---------- пост из пачки Telegram (batches/<дата>.json, поле threads_text и photo) ----------
def tg_post(cfg, key) -> dict | None:
    """Пост Telegram, из которого родился сетап. key = <дата>/<id поста>. None, если токена нет или поста нет."""
    c = conf(cfg)
    if not c["github_token"] or "/" not in key:
        return None
    date, pid = key.split("/", 1)
    h = {"Authorization": f"Bearer {c['github_token']}", "Accept": "application/vnd.github.raw"}
    try:
        r = requests.get(f"https://api.github.com/repos/{c['repo']}/contents/batches/{date}.json",
                         headers=h, params={"ref": c["branch"]}, timeout=30)
    except requests.RequestException as e:
        raise SignalsError(f"GitHub (пачка Telegram) недоступен: {type(e).__name__}") from None
    if r.status_code in (401, 403):
        raise SignalsError(f"GitHub не пускает к пачке Telegram ({r.status_code}): проверьте signals.github_token")
    if r.status_code != 200:
        return None
    return next((p for p in (r.json().get("posts") or []) if p.get("id") == pid), None)


def _norm(t):
    t = re.sub(r"(?<=\d)[ \u00a0\u202f](?=\d{3}\b)", "", t)  # 3 672 -> 3672
    return re.sub(r"(?<=\d),(?=\d)", ".", t)                  # 3672,5 -> 3672.5


def _has(text, num):
    n = num.rstrip("0").rstrip(".") if "." in num else num
    tail = "0*" if "." in n else r"(?:\.0+)?"
    return re.search(rf"(?<![\d.]){re.escape(n)}{tail}(?!\d)", _norm(text)) is not None


def threads_text_ok(r, text) -> list[str]:
    """Текст из Telegram берём, только если в нём те же уровни, что в /signals, и он влезает в Threads."""
    out = [f"нет уровня {r[k]} ({k})" for k in ("entry", "stop", "tp1", "tp2") if r.get(k) and not _has(text, r[k])]
    if "{" in text:
        out.append("остались плейсхолдеры {…}")
    if len(text) > LIMIT:
        out.append(f"{len(text)} знаков, лимит {LIMIT}")
    return out


def _chart(cfg, photo, key):
    """Публичная ссылка на тот же PNG, что в Telegram (бот отдаёт /charts/<файл>), и копия для предпросмотра."""
    if not photo or not re.fullmatch(r"charts/[\w.-]+\.(png|jpg)", photo):
        return None, None
    from pathlib import Path
    url = conf(cfg)["charts_url"].rstrip("/") + "/" + photo
    out = Path(__file__).resolve().parent.parent / cfg.get("media_dir", "media") / ("setup_" + key.replace("/", "_") + Path(photo).suffix)
    try:
        r = requests.get(url, timeout=30)
        if r.status_code != 200 or not r.headers.get("content-type", "").startswith("image/"):
            return None, None
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_bytes(r.content)
    except requests.RequestException:
        return None, None
    return url, str(out)


def plan_draft(cfg, db, r, say) -> int | None:
    """План: текст threads_text из пачки Telegram (если цифры сходятся), иначе шаблон по цифрам /signals."""
    post, why = None, None
    try:
        post = tg_post(cfg, r["key"])
    except SignalsError as e:
        why = str(e)
    url = path = None
    text, source = None, "шаблон"
    if post:
        url, path = _chart(cfg, post.get("photo"), r["key"])
        tt = (post.get("threads_text") or "").strip()
        if tt:
            if DISCLAIMER.lower() not in tt.lower():
                tt = tt.rstrip() + "\n\n" + DISCLAIMER
            bad = threads_text_ok(r, tt)
            if bad:
                why = "threads_text не взят: " + "; ".join(bad)
            else:
                text, source = tt, "telegram"
        else:
            why = "в посте Telegram нет threads_text"
        if post.get("photo") and not url:
            why = (why + "; " if why else "") + "график не скачался"
    if text is None:
        text = text_plan(cfg, r)
    if why and conf(cfg)["github_token"]:
        say(cfg, f"Сетап {r['key']}: {why}. Пост собран {'по шаблону' if source == 'шаблон' else 'из Telegram'}")
    return _add_draft(cfg, db, r, "plan", text, image_url=url, image_path=path, source=source)


def _retire(db, ids, why):
    """Неодобренные черновики, которые устарели (state уже другой): снимаем, не удаляем."""
    for i in ids:
        db.execute("UPDATE drafts SET status='rejected', error=? WHERE id=? AND status IN ('new','approved','held','scheduled')",
                   (why, i))


def _published(db, draft_id) -> bool:
    return bool(draft_id) and bool(db.execute("SELECT 1 FROM posts WHERE draft_id=?", (draft_id,)).fetchone())


def sync(cfg, db, notify=None) -> list[str]:
    """Один проход: прочитать /signals, сравнить со вчерашним состоянием, завести черновики. Возвращает заметки для лога."""
    notes = []
    say = notify or (lambda *_a, **_k: None)
    now_unix, rows = parse(fetch(cfg))
    first_run = _kv(db, "setups_init") is None
    for r in rows:
        if "_error" in r:
            k = f"setup_bad:{r['_raw_key']}"
            if not _kv(db, k):
                say(cfg, f"⚠️ Сетап {r['_raw_key']}: строка не разобрана ({r['_error']}), пост не делаю")
                _kv_set(db, k, 1)
            continue
        sk = f"setup:{r['key']}"
        st = _kv(db, sk)
        if st is None:
            st = {"state": r["state"], "main": None, "events": []}
            fresh = r["state"] == "waiting" and (not r["valid_until"] or (now_unix or 0) < r["valid_until"])
            if fresh:
                st["main"] = plan_draft(cfg, db, r, say)
                notes.append(f"сетап {r['key']}: план на одобрение")
            elif not first_run:
                say(cfg, f"Сетап {r['key']} впервые вижу уже в состоянии {r['state']}: план в Threads не публикую задним числом")
            _kv_set(db, sk, st)
            continue
        if r["state"] == st["state"]:
            continue
        old, st["state"] = st["state"], r["state"]
        main_pub = _published(db, st.get("main"))
        if not main_pub:
            # план так и не вышел в Threads: события без плана не публикуем
            m = st.get("main") and db.execute("SELECT status FROM drafts WHERE id=?", (st["main"],)).fetchone()
            if m and m["status"] in ("new", "approved", "held", "scheduled"):
                _retire(db, [st["main"]], f"устарел: сетап уже в состоянии {r['state']}")
                say(cfg, f"Сетап {r['key']}: план не был опубликован, а состояние уже {r['state']}. Снял его с очереди")
            _kv_set(db, sk, st)
            continue
        _retire(db, st.get("events", []), f"устарел: сетап перешёл {old} → {r['state']}")
        kind = r["state"]
        text = text_event(cfg, r, kind)
        if text is None:
            say(cfg, f"⚠️ Сетап {r['key']}: незнакомый исход «{r['state']}», итог в Threads не написал. Напишите итог вручную")
        else:
            d = _add_draft(cfg, db, r, kind, text, reply_to=st["main"])
            if d:
                st.setdefault("events", []).append(d)
                notes.append(f"сетап {r['key']}: {old} → {r['state']}, ответ на одобрение")
        _kv_set(db, sk, st)
    if first_run:
        _kv_set(db, "setups_init", 1)
    db.commit()
    return notes


def reply_target(db, draft) -> str | None:
    """media_id опубликованного плана, под которым должен выйти ответ-событие."""
    try:
        spec = json.loads(draft["visual_spec"] or "{}")
    except (ValueError, TypeError):
        return None
    did = spec.get("reply_to_draft")
    if not did:
        return None
    row = db.execute("SELECT media_id FROM posts WHERE draft_id=? ORDER BY id DESC LIMIT 1", (did,)).fetchone()
    return row["media_id"] if row else ""
