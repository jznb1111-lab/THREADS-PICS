# Обновление v3.7: сетапы C из Telegram-бота (вместо v3.6, ставить сразу v3.7)

Что внутри: `bot/setups.py` (новый), `bot/cli.py`, `bot/actions.py`, `config.example.json`, `README.md`.
База: v3.5, которая стоит на ПК. `config.json` и база не меняются.

Установка (после вашего «ставь v3.7»):
1. Остановить бота (дождаться конца прохода auto.vbs).
2. Копия на случай отката: `threads-bot\bot` → `backup_20261124_v35\bot`.
3. Распаковать архив в `D:\FX PRO\THREADS ACCS\threads-bot` с заменой файлов.
4. В `config.json` добавить раздел (оба значения вставляете сами, в чат не присылайте):
   `"signals": {"key": "SIGNALS_KEY", "account": "C", "github_token": "ТОКЕН"},`
   ТОКЕН: github.com → Settings → Developer settings → Fine-grained tokens → Generate:
   Repository access → Only select → tg-channel-content; Permissions → Contents: Read-only. Больше ничего.
   Если своего токена нет, бот пробует токен из drafts_repo или github в config.json. Без доступа — пост по шаблону из цифр /signals, без текста и графика из Telegram.
5. Проверка: `python -m bot.cli setups` — покажет тексты, ничего не публикует.

Откат: вернуть файлы из `backup_20261124_v35\bot` и убрать раздел `signals` из config.json.
