"""Аккаунты по отдельности: цифры профиля прямо из статистики Threads, все посты аккаунта (и ручные),
настройки (пауза, постов в день) и запрос новых постов."""
import base64
import json
import time
from datetime import datetime, timezone

import requests

SCHEMA = """
CREATE TABLE IF NOT EXISTS acc_posts (
    media_id TEXT PRIMARY KEY, account TEXT, text TEXT, ts TEXT, permalink TEXT, media_type TEXT,
    views INTEGER, likes INTEGER, replies INTEGER, reposts INTEGER, quotes INTEGER, updated_at TEXT
);
CREATE TABLE IF NOT EXISTS acc_stats (account TEXT PRIMARY KEY, data TEXT, updated_at TEXT);
"""
REQUESTS_PATH = "state/requests.json"


def ensure(db):
    db.executescript(SCHEMA)


def _now():
    return datetime.now(timezone.utc)


def sync(cfg, db, acc, posts_days=30):
    """Обновить профиль и посты одного аккаунта. Бросает исключение при блоке API (5258005)."""
    from .cli import client_for
    ensure(db)
    c = client_for(cfg, acc)
    now = int(time.time())
    d = 86400
    # окна как в приложении: 7 дней, прошлые 7 дней, 30 дней (по дням)
    w7, p7, w30 = c.user_insights(now - 7 * d, now), c.user_insights(now - 14 * d, now - 7 * d), c.user_insights(now - 30 * d, now)
    data = {"w7": w7, "p7": p7, "w30": w30}
    db.execute("INSERT INTO acc_stats(account,data,updated_at) VALUES(?,?,?) ON CONFLICT(account) DO UPDATE SET data=excluded.data, updated_at=excluded.updated_at",
               (acc, json.dumps(data), _now().isoformat()))
    cutoff = _now().timestamp() - posts_days * d
    for t in c.list_threads(limit=60):
        ts = t.get("timestamp") or ""
        try:
            when = datetime.strptime(ts, "%Y-%m-%dT%H:%M:%S%z").timestamp()
        except ValueError:
            when = 0
        if when and when < cutoff:
            continue
        m = {}
        try:
            m = c.insights(t["id"])
        except Exception as e:  # noqa: BLE001
            if "5258005" in str(e):
                raise
        db.execute("""INSERT INTO acc_posts(media_id,account,text,ts,permalink,media_type,views,likes,replies,reposts,quotes,updated_at)
                      VALUES(?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(media_id) DO UPDATE SET text=excluded.text, permalink=excluded.permalink,
                      views=excluded.views, likes=excluded.likes, replies=excluded.replies, reposts=excluded.reposts,
                      quotes=excluded.quotes, updated_at=excluded.updated_at""",
                   (t["id"], acc, t.get("text"), ts, t.get("permalink"), t.get("media_type"), m.get("views"), m.get("likes"),
                    m.get("replies"), m.get("reposts"), m.get("quotes"), _now().isoformat()))
        # те же цифры в историю метрик наших постов, чтобы всё сходилось
        p = db.execute("SELECT id FROM posts WHERE media_id=?", (t["id"],)).fetchone()
        if p and m:
            db.execute("INSERT INTO metrics(post_id,views,likes,replies,reposts,quotes,shares) VALUES(?,?,?,?,?,?,?)",
                       (p["id"], m.get("views"), m.get("likes"), m.get("replies"), m.get("reposts"), m.get("quotes"), m.get("shares")))
    db.commit()


def sync_all(cfg, db) -> list[str]:
    errs = []
    for acc in cfg["accounts"]:
        if not cfg["accounts"][acc].get("access_token"):
            continue
        try:
            sync(cfg, db, acc)
        except Exception as e:  # noqa: BLE001
            if "5258005" in str(e):
                raise
            errs.append(f"{acc}: {str(e)[:120]}")
    return errs


def profile(db, acc) -> dict | None:
    ensure(db)
    r = db.execute("SELECT * FROM acc_stats WHERE account=?", (acc,)).fetchone()
    if not r:
        return None
    d = json.loads(r["data"])
    d["updated_at"] = r["updated_at"]
    return d


def posts(db, acc, limit=60):
    ensure(db)
    q = """SELECT a.*, d.id draft_id, d.visual_spec FROM acc_posts a LEFT JOIN posts p ON p.media_id=a.media_id
           LEFT JOIN drafts d ON d.id=p.draft_id WHERE a.account=? ORDER BY a.ts DESC LIMIT ?"""
    out = []
    for r in db.execute(q, (acc, limit)):
        r = dict(r)
        try:
            s = json.loads(r.pop("visual_spec") or "{}")
        except ValueError:
            s = {}
        r["role"], r["hook"], r["by_bot"] = s.get("role"), s.get("hook"), r["draft_id"] is not None
        out.append(r)
    return out


# ---------- настройки ----------
def set_settings(cfg, acc, paused=None, posts_per_day=None):
    from .cli import CONFIG_PATH, load_config, save_config
    fresh = load_config()  # пишем в свежую копию, чтобы не потерять токены
    a = fresh["accounts"][acc]
    if paused is not None:
        a["paused"] = bool(paused)
    if posts_per_day is not None:
        n = int(posts_per_day)
        if not 0 <= n <= 8:
            raise ValueError("от 0 до 8 постов в день")
        a["posts_per_day"] = n
    save_config(fresh)
    cfg["accounts"][acc].update({k: a.get(k) for k in ("paused", "posts_per_day")})
    return a


# ---------- запрос новых постов ----------
def request_posts(cfg, db, acc, n=3, note=""):
    """Сначала берёт из запаса этого аккаунта (сразу на одобрение в Telegram и панель).
    Остаток пишет локальная модель (Ollama, gemma) в фоне; если она выключена, заказ уходит Claude
    (state/requests.json в репозитории пачек, выполняется с утренней пачкой).
    Возвращает (из запаса, осталось, способ: 'local' | 'claude' | None)."""
    n = max(1, min(int(n), 10))
    got = [r["id"] for r in db.execute("SELECT id FROM drafts WHERE account=? AND status='reserve' ORDER BY id LIMIT ?", (acc, n))]
    for i in got:
        db.execute("UPDATE drafts SET status='new' WHERE id=?", (i,))
    db.commit()
    left = n - len(got)
    how = None
    if left > 0:
        ol = cfg.get("ollama") or {}
        if ol.get("enabled"):
            import threading
            threading.Thread(target=_local_write, args=(acc, left, note), daemon=True).start()
            how = "local"
        elif _push_request(cfg, {"account": acc, "n": left, "note": (note or "")[:300],
                                 "at": _now().isoformat(timespec="seconds"), "status": "new"}):
            how = "claude"
    return len(got), left, how


def _local_write(acc, n, note):
    """Фоновая генерация локальной моделью; готовые посты встают на одобрение."""
    from .cli import _import_items, get_db, load_config
    from .local_llm import make_drafts
    from .tg import kv_set, notify
    cfg = load_config()
    db = get_db(cfg)
    ol = cfg.get("ollama") or {}
    try:
        recent = [x["text"] for x in db.execute("SELECT text FROM drafts WHERE account=? ORDER BY id DESC LIMIT 20", (acc,))]
        if note:
            recent.append(f"ТЕМА ЗАПРОСА ОТ ИЛЬИ (учти её): {note}")
        kw = {"model": ol.get("model", "gemma3:12b")}
        if ol.get("host"):
            kw["host"] = ol["host"]
        items = make_drafts(acc, n=n, recent=recent, **kw)
        added, _ = _import_items(db, items)
        kv_set(db, "kick", "1")
        db.commit()
        if not added:
            notify(cfg, f"Модель не написала годных постов для {acc} (всё отсеял стоп-лист). Попробуйте ещё раз.")
    except Exception as e:  # noqa: BLE001
        notify(cfg, f"Локальная модель не ответила для {acc}: {str(e)[:150]}")
    finally:
        db.close()


def _push_request(cfg, item) -> bool:
    src = cfg.get("drafts_repo") or {}
    token = src.get("token") or (cfg.get("github") or {}).get("token")
    if not (src.get("repo") and token):
        return False
    url = f"https://api.github.com/repos/{src['repo']}/contents/{REQUESTS_PATH}"
    h = {"Authorization": f"Bearer {token}", "Accept": "application/vnd.github+json"}
    branch = src.get("branch", "main")
    old = requests.get(url, headers=h, params={"ref": branch}, timeout=30)
    items, sha = [], None
    if old.status_code == 200:
        sha = old.json()["sha"]
        try:
            items = json.loads(base64.b64decode(old.json()["content"]).decode("utf-8"))
        except ValueError:
            items = []
    items.append(item)
    body = {"message": f"request {item['n']} posts for {item['account']}", "branch": branch,
            "content": base64.b64encode(json.dumps(items, ensure_ascii=False, indent=1).encode("utf-8")).decode()}
    if sha:
        body["sha"] = sha
    r = requests.put(url, headers=h, json=body, timeout=60)
    return r.status_code < 300
