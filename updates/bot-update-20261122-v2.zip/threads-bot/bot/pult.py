"""Пульт в Telegram: одно закреплённое сообщение, бот сам его обновляет.

Экраны (всё в одном сообщении, кнопки переключают): пульт → очередь (сегодня/завтра) → пост (⏩ 🚀 🗑),
пульт → неделя. Новые сообщения бот шлёт только когда нужно решение: пост на одобрение, коммент, ошибка.
"""
import hashlib
import html
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

from .tg import api, kv_get, kv_set

WEEKDAYS = ["пн", "вт", "ср", "чт", "пт", "сб", "вс"]
IDLE_RESET_MIN = 10  # если пульт оставили на другом экране, через 10 минут он возвращается на главный


def _tz(cfg):
    return ZoneInfo(cfg.get("timezone", "Europe/Chisinau"))


def _e(s):
    return html.escape(s or "")


def _first(text, n=34):
    line = (text or "").strip().split("\n")[0]
    return line if len(line) <= n else line[:n - 1] + "…"


def _local(cfg, iso):
    return datetime.fromisoformat(iso).astimezone(_tz(cfg))


def _utc_to_local(cfg, s):
    from datetime import timezone
    t = datetime.fromisoformat(str(s).replace(" ", "T"))
    if not t.tzinfo:
        t = t.replace(tzinfo=timezone.utc)
    return t.astimezone(_tz(cfg))


def _num(v):
    return f"{v:,}".replace(",", " ")


def _ago(cfg, iso):
    if not iso:
        return "ещё не собиралась"
    m = int((datetime.now(_tz(cfg)) - datetime.fromisoformat(iso)).total_seconds() // 60)
    return "только что" if m < 1 else f"{m} мин назад" if m < 60 else f"{m // 60} ч назад"


# ---------- экраны ----------
def home(cfg, db):
    from .reports import kpis, _arrow
    tz = _tz(cfg)
    now = datetime.now(tz)
    day_end = (now.replace(hour=0, minute=0, second=0, microsecond=0) + timedelta(days=1)).isoformat()
    today_q = db.execute("SELECT COUNT(*) c FROM drafts WHERE status='scheduled' AND scheduled_at<?", (day_end,)).fetchone()["c"]
    waiting = db.execute("SELECT COUNT(*) c FROM drafts WHERE status='new'").fetchone()["c"]
    nxt = db.execute("SELECT * FROM drafts WHERE status='scheduled' ORDER BY scheduled_at LIMIT 1").fetchone()
    last = db.execute("""SELECT p.*, d.text, (SELECT views FROM metrics m WHERE m.post_id=p.id ORDER BY taken_at DESC LIMIT 1) v
                         FROM posts p JOIN drafts d ON d.id=p.draft_id ORDER BY p.published_at DESC LIMIT 1""").fetchone()
    k = kpis(cfg, db)
    c_wait = db.execute("SELECT COUNT(*) c FROM comments WHERE status IN ('new','drafted')").fetchone()["c"]

    t = [f"Сегодня   {today_q} в очереди" + (f" · ждут ✅ {waiting}" if waiting else "")]
    if nxt:
        w = _local(cfg, nxt["scheduled_at"])
        when = f"{w:%H:%M}" if w.date() == now.date() else f"{WEEKDAYS[w.weekday()]} {w:%H:%M}"
        t += [f"Следующий {when} {nxt['account']}", f"  «{_first(nxt['text'])}»"]
    else:
        t.append("Следующий —")
    if last:
        w = _utc_to_local(cfg, last["published_at"])
        t.append(f"Последний {w:%H:%M} {last['account']}  👁 {'—' if last['v'] is None else _num(last['v'])}")
    c, d = k["cur"], k["delta"]
    t += ["", f"За 7 дней  👁 {_num(c['views'])} {_arrow(d['views'])}".rstrip(),
          f"           ❤️ {c['likes']}  💬 {c['replies']}"]
    if k["best"]:
        b = k["best"]
        t += [f"Лучший    {b['account']}  👁 {_num(b['views'] or 0)}", f"  «{_first(b['text'])}»"]
    if k["funnel"] is not None:
        f = k["funnel"]
        t.append(f"Воронка   a {f['A']} · b {f['B']} · c {f['C']}")
    head = f"<b>Пульт</b> · {WEEKDAYS[now.weekday()]} {now:%d.%m, %H:%M}"
    foot = f"<i>статистика {_ago(cfg, k['metrics_at'])}</i>"
    text = f"{head}\n<pre>{_e(chr(10).join(t))}</pre>\n{foot}"
    kb = [[{"text": "🗓 Очередь", "callback_data": "qd:0"}, {"text": "📊 Неделя", "callback_data": "pw:0"},
           {"text": f"💬 {c_wait}" if c_wait else "💬", "callback_data": "pc:0"}]]
    return text, {"inline_keyboard": kb}


def queue(cfg, db, day=0):
    tz = _tz(cfg)
    start = (datetime.now(tz).replace(hour=0, minute=0, second=0, microsecond=0) + timedelta(days=day))
    rows = list(db.execute("SELECT * FROM drafts WHERE status='scheduled' AND scheduled_at>=? AND scheduled_at<? ORDER BY scheduled_at",
                           (start.isoformat(), (start + timedelta(days=1)).isoformat())))
    if day == 0:  # сегодня: и то, что уже просрочено и ждёт выхода
        rows = list(db.execute("SELECT * FROM drafts WHERE status='scheduled' AND scheduled_at<? ORDER BY scheduled_at",
                               ((start + timedelta(days=1)).isoformat(),)))
    title = "сегодня" if day == 0 else "завтра" if day == 1 else f"{WEEKDAYS[start.weekday()]} {start:%d.%m}"
    lines = [f"{_local(cfg, d['scheduled_at']):%H:%M}  {d['account']}  {_first(d['text'], 26)}" for d in rows] or ["пусто"]
    later = db.execute("SELECT COUNT(*) c FROM drafts WHERE status='scheduled' AND scheduled_at>=?",
                       ((start + timedelta(days=1)).isoformat(),)).fetchone()["c"]
    text = f"<b>🗓 Очередь на {title}</b>\n<pre>{_e(chr(10).join(lines))}</pre>"
    if later:
        text += f"\n<i>дальше ещё {later}</i>"
    btns = [{"text": f"{_local(cfg, d['scheduled_at']):%H:%M} {d['account']}", "callback_data": f"qp:{d['id']}:{day}"} for d in rows]
    kb = [btns[i:i + 3] for i in range(0, len(btns), 3)]
    nav = [{"text": "◀ Пульт", "callback_data": "pv:0"}]
    if day > 0:
        nav.append({"text": "◀ " + ("Сегодня" if day == 1 else "Назад"), "callback_data": f"qd:{day - 1}"})
    if day < 6:
        nav.append({"text": ("Завтра" if day == 0 else "Дальше") + " ▶", "callback_data": f"qd:{day + 1}"})
    kb.append(nav)
    return text, {"inline_keyboard": kb}


def post(cfg, db, did, day=0):
    d = db.execute("SELECT * FROM drafts WHERE id=?", (int(did),)).fetchone()
    if not d or d["status"] != "scheduled":
        return queue(cfg, db, day)
    who = ((cfg["accounts"].get(d["account"]) or {}).get("username") or d["account"]).lstrip("@")
    w = _local(cfg, d["scheduled_at"])
    text = f"<b>{d['account']} · @{_e(who)} · {WEEKDAYS[w.weekday()]} {w:%H:%M}</b>\n\n{_e(d['text'])}"
    kb = [[{"text": "⏩ +2 ч", "callback_data": f"qm:{d['id']}:{day}"},
           {"text": "🚀 Сейчас", "callback_data": f"qn:{d['id']}:{day}"},
           {"text": "🗑 Снять", "callback_data": f"qh:{d['id']}:{day}"}],
          [{"text": "◀ Очередь", "callback_data": f"qd:{day}"}]]
    return text[:4000], {"inline_keyboard": kb}


def week(cfg, db):
    from .reports import weekly_pre
    return weekly_pre(cfg, db), {"inline_keyboard": [[{"text": "◀ Пульт", "callback_data": "pv:0"}]]}


# ---------- сообщение-пульт ----------
def _show(cfg, db, view, text, kb, msg_id=None):
    """Показывает экран в сообщении-пульте (правит его) или создаёт и закрепляет новое."""
    t = cfg["telegram"]
    msg_id = msg_id or kv_get(db, "pult_id")
    digest = hashlib.md5((text + str(kb)).encode()).hexdigest()
    if msg_id and kv_get(db, "pult_hash") == digest and kv_get(db, "pult_id") == str(msg_id):
        return
    sent = False
    if msg_id:
        try:
            api(t["token"], "editMessageText", chat_id=t["chat_id"], message_id=int(msg_id), text=text,
                parse_mode="HTML", reply_markup=kb, disable_web_page_preview="true")
            sent = True
        except RuntimeError as e:
            sent = "not modified" in str(e)
    if not sent:
        m = api(t["token"], "sendMessage", chat_id=t["chat_id"], text=text, parse_mode="HTML", reply_markup=kb,
                disable_web_page_preview="true")
        msg_id = m["message_id"]
        try:
            api(t["token"], "pinChatMessage", chat_id=t["chat_id"], message_id=msg_id, disable_notification="true")
        except Exception:  # noqa: BLE001
            pass
    kv_set(db, "pult_id", msg_id)
    kv_set(db, "pult_hash", digest)
    kv_set(db, "pult_view", view)
    kv_set(db, "pult_touched", datetime.now(_tz(cfg)).isoformat())
    db.commit()


def refresh(cfg, db, new=False):
    """Обновить пульт (главный экран). Если человек сейчас листает очередь, не мешаем ему 10 минут."""
    if not (cfg.get("telegram") or {}).get("chat_id"):
        return
    if not new and kv_get(db, "pult_view", "home") != "home":
        touched = kv_get(db, "pult_touched")
        if touched and datetime.fromisoformat(touched) > datetime.now(_tz(cfg)) - timedelta(minutes=IDLE_RESET_MIN):
            return
    if new:
        db.execute("DELETE FROM kv WHERE key IN ('pult_id','pult_hash')")
    text, kb = home(cfg, db)
    _show(cfg, db, "home", text, kb)


def on_callback(cfg, db, act, arg, msg):
    """Кнопки пульта. Возвращает (текст всплывашки или None, было ли изменение в очереди)."""
    from . import actions
    parts = arg.split(":")
    mid = msg["message_id"]
    changed = False
    note = None
    if act == "pv":
        text, kb = home(cfg, db); view = "home"
    elif act == "pw":
        text, kb = week(cfg, db); view = "week"
    elif act == "qd":
        text, kb = queue(cfg, db, int(parts[0])); view = "queue"
    elif act == "qp":
        text, kb = post(cfg, db, parts[0], int(parts[1])); view = "post"
    elif act in ("qm", "qn", "qh"):
        did, day = parts[0], int(parts[1])
        if act == "qm":
            w = actions.move(cfg, db, did)
            note = f"#{did} → {w:%d.%m %H:%M}"
        elif act == "qn":
            actions.publish_now(cfg, db, did)
            note = "Выйдет в ближайшие минуты (не раньше часа после прошлого поста аккаунта)"
        else:
            actions.hold(cfg, db, did)
            note = "Снят с очереди. Вернуть можно в веб-панели"
        changed = True
        text, kb = queue(cfg, db, day); view = "queue"
    elif act == "pc":
        n = db.execute("SELECT COUNT(*) c FROM comments WHERE status IN ('new','drafted')").fetchone()["c"]
        if not n:
            return "Новых комментов нет", False
        db.execute("DELETE FROM tg_csent WHERE comment_id IN (SELECT id FROM comments WHERE status IN ('new','drafted'))")
        db.commit()
        from .tg import send_comments
        send_comments(cfg, db)
        return f"Прислал комменты: {n}", False
    else:
        return None, False
    _show(cfg, db, view, text, kb, msg_id=mid)
    return note, changed
